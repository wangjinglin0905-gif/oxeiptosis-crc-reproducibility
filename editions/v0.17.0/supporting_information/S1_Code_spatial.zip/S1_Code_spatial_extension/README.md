# S1 Code. Spatial-analysis code and audit materials

Version: v15 editorial packaging, 18 November 2026.

## Scope

This archive accompanies the spatial extension described in S3 Text and S4 Text and the derived results in S28–S37 Tables. It contains the executed code copies, frozen analysis contracts, provenance/quality-assurance records, and the corresponding derived tables. The earlier bulk analysis and its public reproduction archive are not repackaged here.

## Important limits

- These are auditable copies of the executed files, not a one-click portable pipeline. The code retains original absolute execution paths, local environment assumptions, and source-data dependencies. Adapt those paths deliberately before rerunning.
- Large original public expression matrices, images, FASTQ files, and compressed source archives are not duplicated. Obtain them from the accessions and persistent identifiers reported in the manuscript and S3/S4 Texts.
- The archive supports inspection of the added spatial analyses. It does not establish independent biological replication, new pathology review, functional calibration of OX4, or a new public release DOI.
- The local pathology-suitability packet was not rated and supplies no validation evidence.

## Layout

- `code/GSE280315_scale_pilot`: scale/region pilot and technical splitting.
- `code/GSE280315_matched_controls`: expression/detection-matched spatial backgrounds.
- `code/GSE226997_validation`: native-spot analysis, source acquisition, original-matrix audit, and image/coordinate checks.
- `code/morphology`: six-patient morphology analysis, frozen contract, numerical QA, and plotting.
- `qa`: retained stage manifests, numerical checks, and provenance summaries.
- `derived_results`: S3/S4 Text Markdown sources and S28–S37 Tables.

`MANIFEST_SHA256.csv` lists every included file and its SHA-256 hash. The manifest does not list itself.
