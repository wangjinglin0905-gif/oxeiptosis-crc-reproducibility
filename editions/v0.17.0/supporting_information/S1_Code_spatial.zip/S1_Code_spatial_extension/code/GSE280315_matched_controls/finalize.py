from pathlib import Path
import sys,json,hashlib
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R/'work/public_preflight_20261117/deps'));sys.path.insert(0,str(R/'work/spatial_pilot_20261117'))
import numpy as np,pandas as pd,h5py,scipy
from scipy import sparse
from run import score,rho
O=R/'outputs/GSE280315_matched_controls_v01_2026-11-17';P=R/'outputs/GSE280315_region_pilot_v01_2026-11-17'
s=pd.read_csv(O/'summary.csv');reps=pd.read_csv(O/'replicates.csv');old=pd.read_csv(P/'primary_64um.csv')
assert s['sample'].nunique()==5 and len(reps)==len(s)*10 and reps.rho.notna().all()
rows=[];balance=[];availability={}
for name,t in s.groupby('sample'):
 c=t[t['set'].str.startswith('matched_')];ox=t[t['set']=='OX4'].iloc[0];ref=t[t['set']=='stromal'].iloc[0]
 assert len(c)==100
 prev=old[old['sample']==name].iloc[0]
 assert abs(ox.score_depth_rho-prev.score_logdepth_rho)<1e-12 and abs(ox.all4_positive-prev.all4_positive_fraction)<1e-12
 pools=pd.read_csv(O/name/'candidate_pools.csv');sets=json.loads((O/name/'sets.json').read_text())
 assert (pools.log2_mean_ratio.abs()<=1+1e-12).all() and (pools.detection_difference.abs()<=.05+1e-12).all()
 marg=pd.read_csv(O/name/'gene_marginals.csv.gz').set_index('gene');seen=set();used=[]
 for label,genes in sets:
  if not label.startswith('matched_'):continue
  key=tuple(sorted(genes));assert key not in seen and len(set(genes))==4;seen.add(key);used+=genes
  for g,other in zip(['KEAP1','PGAM5','AIFM1','OTUD1'],genes):
   q=pools[(pools.target==g)&(pools.candidate==other)];assert len(q)==1
   balance.append({'sample':name,'set':label,**q.iloc[0].to_dict()})
 pct=float((c.median_split_rho<ox.median_split_rho).mean()*100)
 ppct=float((c.median_partial_rho<ox.median_partial_rho).mean()*100)
 rows.append({'sample':name,'OX4_rho':ox.median_split_rho,'matched_p10':c.median_split_rho.quantile(.1),'matched_median':c.median_split_rho.median(),'matched_p90':c.median_split_rho.quantile(.9),'OX4_percentile':pct,'OX4_partial':ox.median_partial_rho,'matched_partial_median':c.median_partial_rho.median(),'OX4_partial_percentile':ppct,'stromal_rho':ref.median_split_rho,'stromal_partial':ref.median_partial_rho,'unique_matched_genes':len(set(used)),'OX4_old30_rho':prev.median_split_rho})
 availability[name]=json.loads((O/name/'reference_availability.json').read_text())
b=pd.DataFrame(balance);b.to_csv(O/'selected_match_balance.csv',index=False);v=pd.DataFrame(rows);v.to_csv(O/'comparison.csv',index=False)
# Independent aggregation via bincount for the first matched set, then recreate its first split.
p=Path('G:/Doc workout/_公共数据集/data/GEO/GSE280315/GSM8594567_P1CRC_filtered_feature_bc_matrix.h5')
sets=json.loads((O/'P1CRC/sets.json').read_text());k,entry=next((k,x) for k,x in enumerate(sets) if x[0]=='matched_000');genes=entry[1]
with h5py.File(p,'r') as f:
 m=f['matrix'];names=[x.decode() for x in m['features/name'][:]];bc=[x.decode() for x in m['barcodes'][:]]
 mat=sparse.csc_matrix((m['data'][:],m['indices'][:],m['indptr'][:]),shape=tuple(m['shape'][:]))
 counts=mat[[names.index(g) for g in genes]].toarray().T;tot=np.asarray(mat.sum(axis=0)).ravel()
rc=np.array([[int(x.split('_')[2]),int(x.split('_')[3].split('-')[0])] for x in bc]);keys,inv=np.unique(rc//8,axis=0,return_inverse=True)
t=np.bincount(inv,weights=tot).astype(np.int64);ok=(np.bincount(inv)>=32)&(t>=500)
c=np.column_stack([np.bincount(inv,weights=counts[:,j]) for j in range(4)]).astype(np.int64)[ok];t=t[ok]
full,mu,sd=score(c,t);rnd=np.random.default_rng(np.random.SeedSequence([20261118,8594567,k,0]));ca=rnd.binomial(c,.5);ta=ca.sum(axis=1)+rnd.binomial(t-c.sum(axis=1),.5)
a,_,_=score(ca,ta,mu,sd);bb,_,_=score(c-ca,t-ta,mu,sd)
expected=reps[(reps['sample']=='P1CRC')&(reps['set']=='matched_000')&(reps.replicate==0)].iloc[0].rho
err=abs(rho(a,bb)-expected);assert err<1e-12
lines=['|组织|OX4拆半rho|匹配对照中位数|匹配对照P10–P90|OX4经验百分位|基质参照rho|','|---|---:|---:|---:|---:|---:|']
for x in rows:lines.append(f'|{x["sample"]}|{x["OX4_rho"]:.3f}|{x["matched_median"]:.3f}|{x["matched_p10"]:.3f}–{x["matched_p90"]:.3f}|{x["OX4_percentile"]:.0f}%|{x["stromal_rho"]:.3f}|')
table='\n'.join(lines);(O/'table.md').write_text(table,encoding='utf-8')
qa={'status':'completed','n_sections':5,'n_sets':len(s),'n_splits':len(reps),'matched_sets':500,'match_records':len(b),'independent_bincount_split_abs_error':err,'reference_availability':availability,'versions':{'numpy':np.__version__,'pandas':pd.__version__,'scipy':scipy.__version__,'h5py':h5py.__version__}}
(O/'qa.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2),encoding='utf-8')
print(table);print(v[['sample','OX4_partial','matched_partial_median','OX4_partial_percentile','stromal_partial','unique_matched_genes']].to_string(index=False));print(json.dumps(qa,ensure_ascii=False))
