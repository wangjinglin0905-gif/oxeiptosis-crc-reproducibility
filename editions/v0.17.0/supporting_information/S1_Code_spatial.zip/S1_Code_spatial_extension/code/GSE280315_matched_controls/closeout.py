from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parents[2];O=R/'outputs/GSE280315_matched_controls_v01_2026-11-17'
heading='## 2026-11-17：GSE280315 匹配对照与阳性参照 v01完成'
entry='''

## 2026-11-17：GSE280315 匹配对照与阳性参照 v01完成

- 入口 outputs/GSE280315_matched_controls_v01_2026-11-17/匹配对照与阳性参照检验报告_v01.md。64μm固定主尺度；5组织各100匹配集合，另含OX4和基质参照，共510组、5100次技术拆分完成并核验。
- OX4原始拆半rho位于匹配分布66–95百分位，全部高于匹配中位数；深度条件化百分位31/34/90/37/33，无组织低于P10。不支持OX4特异的额外不稳定性，但不改变其绝对稳定性不足、不得称空间活动验证的前轮裁定。
- 基质参照COL1A1/COL1A2/COL3A1/DCN在3癌组织rho约0.96，癌旁0.649/0.845；仅技术可测参照，没有独立病理定位真值。预设上皮组因5份feature/name均缺精确KRT18符号而全部未运行，未换基因/改三成员。
- 匹配约束：区域均值0.5–2倍、检出率差≤0.05，每成员最近30候选，固定种子。2000条实际匹配记录及集合唯一性通过；原始H5独立bincount重算一匹配组的首拆分rho误差0。全部结果保留。
- 下一决策：本支线作为测量边界案例；停止追加任意尺度/平滑。普遍方法学升级仍缺独立真值与跨评分验证，优先评估原稿有限重构。本轮未进行HE区室验证、蛋白验证、稿件修订或对外上传。
'''
p=R/'PROJECT_STATE.md'
if heading not in p.read_text(encoding='utf-8-sig'):
 with p.open('a',encoding='utf-8',newline='') as f:f.write(entry.replace('\n','\r\n'))
m={'status':'completed with epithelial reference unavailable; no independent histological validation','date':'2026-11-17','inputs':{x.parent.name:json.loads(x.read_text()) for x in O.glob('*/run.json')},'scripts':{str(x.relative_to(R)):hashlib.sha256(x.read_bytes()).hexdigest() for x in Path(__file__).parent.iterdir() if x.is_file()},'files':{str(x.relative_to(O)):hashlib.sha256(x.read_bytes()).hexdigest() for x in O.rglob('*') if x.is_file() and x.name!='manifest.json'}}
(O/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2),encoding='utf-8')
for name,digest in m['files'].items():assert hashlib.sha256((O/name).read_bytes()).hexdigest()==digest
print('State updated; output SHA256 verified:',len(m['files']))
