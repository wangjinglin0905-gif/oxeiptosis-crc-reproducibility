from pathlib import Path
import sys,gzip,json
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R/'work/public_preflight_20261117/deps'))
import numpy as np,pandas as pd,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image
O=R/'outputs/GSE280315_region_pilot_v01_2026-11-17';D=Path('G:/Doc workout/_公共数据集/data/GEO/GSE280315')
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','pdf.fonttype':42})
s=pd.read_csv(O/'summary.csv');colors=['#0072B2','#D55E00','#009E73','#CC79A7','#777777']
fig,axs=plt.subplots(2,2,figsize=(10,7),layout='constrained')
panels=[('all4_positive_fraction','Regions with all four genes detected',.8),('median_split_rho','Median molecule split-half rho',.7),('score_logdepth_rho','Score vs log library depth (rho)',.5),('grid_shift_rho_shared_bins','Shifted-grid agreement (shared data)',None)]
for ax,(col,title,cut),letter in zip(axs.flat,panels,'abcd'):
 for (sample,t),color in zip(s.groupby('sample',sort=False),colors):
  ax.plot(t.scale_um,t[col],'-o',label=sample,color=color,markersize=4)
  if col=='median_split_rho':ax.fill_between(t.scale_um,t.p10_split_rho,t.p90_split_rho,color=color,alpha=.1)
 if cut is not None:ax.axhline(cut,color='gray',ls='--',lw=1)
 ax.set(xlabel='Square side (micrometres)',ylabel=title,xticks=[32,64,128,256],ylim=(-.05,1.05));ax.set_title(letter,loc='left',fontweight='bold')
axs[0,0].legend(fontsize=8,ncol=2)
fig.suptitle('Technical spatial pilot: sections are not independent validation cohorts',fontsize=12)
fig.savefig(O/'stability_diagnostics.png',dpi=170);fig.savefig(O/'stability_diagnostics.svg');plt.close(fig)
fig,axs=plt.subplots(5,3,figsize=(10,14),layout='constrained');qc=[]
for i,sample in enumerate(['P1CRC','P2CRC','P5CRC','P3NAT','P5NAT']):
 p=next(D.glob('*_'+sample+'_tissue_lowres_image.png.gz'));prefix=p.name.replace('_tissue_lowres_image.png.gz','')
 im=np.array(Image.open(gzip.open(p,'rb')).convert('RGB'));sf=json.load(gzip.open(D/(prefix+'_scalefactors_json.json.gz'),'rt'))
 z=np.load(O/sample/'base_bin_maps.npz');x=z['x']*sf['tissue_lowres_scalef'];y=z['y']*sf['tissue_lowres_scalef']
 inside=(x>=0)&(x<im.shape[1])&(y>=0)&(y<im.shape[0]);qc.append({'sample':sample,'image_width':im.shape[1],'image_height':im.shape[0],'bin_centres_in_image_fraction':float(inside.mean()),'source':'archived lowres + official scalefactor','precision':'overview only, not cellular registration'})
 for j in range(3):axs[i,j].imshow(im);axs[i,j].set_axis_off()
 pick=np.arange(0,len(x),50);axs[i,1].scatter(x[pick],y[pick],s=.1,c='#00FFFF',alpha=.45)
 v=z['score_64'];pick=np.flatnonzero(np.isfinite(v))[::15]
 sc=axs[i,2].scatter(x[pick],y[pick],c=v[pick],s=.3,cmap='coolwarm',vmin=-1.5,vmax=1.5,alpha=.65,rasterized=True)
 for j in range(3):axs[i,j].set_xlim(0,im.shape[1]);axs[i,j].set_ylim(im.shape[0],0)
 axs[i,0].set_title(sample,loc='left',fontsize=10)
axs[0,0].set_title('a  H&E overview: P1CRC',loc='left');axs[0,1].set_title('b  In-tissue bin centres',loc='left');axs[0,2].set_title('c  64 um score (diagnostic only)',loc='left')
fig.colorbar(sc,ax=axs[:,2],shrink=.3,label='Within-section spatial score; not activity')
fig.savefig(O/'lowres_alignment_QA.png',dpi=140);plt.close(fig)
pd.DataFrame(qc).to_csv(O/'image_coordinate_QA.csv',index=False)
print('plots rendered')
