from pathlib import Path
import json, hashlib

root = Path(__file__).resolve().parents[2]
out = root / 'outputs/GSE280315_region_pilot_v01_2026-11-17'
state = root / 'PROJECT_STATE.md'
heading = '## 2026-11-17：GSE280315 区域聚合与稳定性先导 v01完成'
entry = '''

## 2026-11-17：GSE280315 区域聚合与稳定性先导 v01完成

- 入口 outputs/GSE280315_region_pilot_v01_2026-11-17/区域聚合与稳定性先导报告_v01.md；五份组织、四种尺度、600次技术拆分已实际运行完成，内部核验通过。不是独立生物学验证。
- 64μm主尺度拆半rho中位数：P1CRC 0.358、P2CRC 0.501、P5CRC 0.253、P3NAT 0.358、P5NAT 0.285，均低于事先固定的0.7工作门槛。全部20个组织×尺度组合均未同时通过覆盖/稳定性/深度关联条件。P2CRC 256μm拆半rho 0.822，但评分–深度rho 0.729。
- 四成员均检出不是纳入过滤；零计数保留。空间评分是组织/尺度内标准化的OX4类比构造，不直接转移TCGA单位。规则方格不是病理区室；不将区域当患者，不用技术拆分分布冒充患者CI。
- 五份低分辨率H&E叠加未见明显整体翻转/错位；未完成细胞级配准或病理区室独立评定。直接稀疏矩阵抽查5区域计数一致，固定拆分rho重建误差5.55e-17。
- 裁定：停止把当前图推进为空间OX4活性验证。保留为测量边界先导；若进一步发展方法学，需另设表达/检出匹配参照、阳性结构参照及独立定义的区室。未证明问题为OX4特异，也未证明无生物学效应。
- 原始公共库输入只读，未新增科研数据下载，未改投稿基线/公开归档；未实施新对照或病理区室分析。脚本 work/spatial_pilot_20261117/，结果及输入/输出哈希见阶段manifest。
'''
old = state.read_text(encoding='utf-8-sig')
if heading not in old:
    with state.open('a', encoding='utf-8', newline='') as f:
        f.write(entry.replace('\n', '\r\n'))
report = out / '区域聚合与稳定性先导报告_v01.md'
assert report.is_file() and len(report.read_text(encoding='utf-8')) > 3000
p = out / 'manifest.json'
m = json.loads(p.read_text(encoding='utf-8'))
m['report'] = report.name
m['source_hashes'] = {str(x.relative_to(root)): hashlib.sha256(x.read_bytes()).hexdigest() for x in Path(__file__).parent.glob('*') if x.is_file()}
m['files'] = {str(x.relative_to(out)): hashlib.sha256(x.read_bytes()).hexdigest() for x in out.rglob('*') if x.is_file() and x.name != 'manifest.json'}
p.write_text(json.dumps(m, ensure_ascii=False, indent=2), encoding='utf-8')
for name, digest in m['files'].items():
    assert hashlib.sha256((out / name).read_bytes()).hexdigest() == digest
print(f'Report saved; project state updated; {len(m["files"])} output hashes verified.')
