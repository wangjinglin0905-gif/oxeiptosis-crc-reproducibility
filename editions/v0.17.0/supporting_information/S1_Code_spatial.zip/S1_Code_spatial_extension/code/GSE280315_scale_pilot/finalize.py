from pathlib import Path
import sys,json,hashlib,platform,shutil
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R/'work/public_preflight_20261117/deps'))
import numpy as np,pandas as pd,h5py
from scipy import sparse
from run import score,rho
O=R/'outputs/GSE280315_region_pilot_v01_2026-11-17';D=Path('G:/Doc workout/_公共数据集/data/GEO/GSE280315');G=['KEAP1','PGAM5','AIFM1','OTUD1']
s=pd.read_csv(O/'summary.csv');reps=pd.read_csv(O/'split_replicates.csv')
assert len(s)==20 and len(reps)==600 and reps.split_rho.notna().all()
assert (s.eligible_regions>=50).all()
p=D/'GSM8594567_P1CRC_filtered_feature_bc_matrix.h5'
with h5py.File(p,'r') as f:
 m=f['matrix'];n=[x.decode() for x in m['features/name'][:]];bc=[x.decode() for x in m['barcodes'][:]]
 mat=sparse.csc_matrix((m['data'][:],m['indices'][:],m['indptr'][:]),shape=tuple(m['shape'][:]))
rc=np.array([[int(x.split('_')[2]),int(x.split('_')[3].split('-')[0])] for x in bc])
t=pd.read_csv(O/'P1CRC/regions_64um_origin.csv.gz');checks=[]
for _,row in t[t.eligible].iloc[np.linspace(0,t.eligible.sum()-1,5,dtype=int)].iterrows():
 sel=(rc[:,0]//8==int(row.grid_row))&(rc[:,1]//8==int(row.grid_col))
 v=np.asarray(mat[[n.index(g) for g in G]][:,sel].sum(axis=1)).ravel();total=int(mat[:,sel].sum())
 assert np.array_equal(v,row[[g+'_UMI' for g in G]].to_numpy()) and total==row.total_UMI and sel.sum()==row.n_bins
 checks.append({'row':int(row.grid_row),'col':int(row.grid_col),'pass':True})
del mat
tab=t[t.eligible];c=tab[[g+'_UMI' for g in G]].to_numpy(dtype=np.int64);tot=tab.total_UMI.to_numpy(dtype=np.int64)
ref=json.loads((O/'P1CRC/normalization_reference.json').read_text())['64'];rng=np.random.default_rng(np.random.SeedSequence([20261117,8594567,64,0]))
ca=rng.binomial(c,.5);ta=ca.sum(axis=1)+rng.binomial(tot-c.sum(axis=1),.5)
a,_,_=score(ca,ta,np.array(ref['mean']),np.array(ref['sd']));b,_,_=score(c-ca,tot-ta,np.array(ref['mean']),np.array(ref['sd']))
diff=abs(rho(a,b)-reps.query("sample=='P1CRC' and scale_um==64 and replicate==0").iloc[0].split_rho);assert diff<1e-12
shutil.copyfile(Path(__file__).parent/'analysis_contract.json',O/'analysis_contract.json')
main=s[s.scale_um==64].copy();main.to_csv(O/'primary_64um.csv',index=False)
lines=['|组织|合格区域|四成员均检出|拆半rho中位数|深度条件化拆半rho|评分–深度rho|平移网格rho|','|---|---:|---:|---:|---:|---:|---:|']
for _,v in main.iterrows():
 lines.append(f'|{v["sample"]}|{v.eligible_regions}|{v.all4_positive_fraction:.1%}|{v.median_split_rho:.3f}|{v.median_depth_partial_split_rho:.3f}|{v.score_logdepth_rho:.3f}|{v.grid_shift_rho_shared_bins:.3f}|')
(O/'primary_table.md').write_text('\n'.join(lines),encoding='utf-8')
import scipy,matplotlib,pyarrow,psutil
manifest={'status':'completed and internally checked; not independent biological validation','date':'2026-11-17','direct_region_checks':checks,'split_reproduction_abs_difference':diff,'versions':{m.__name__:m.__version__ for m in [np,pd,h5py,scipy,matplotlib,pyarrow,psutil]},'python':platform.python_version(),'source_hashes':{str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path(__file__).parent.glob('*') if p.is_file()},'files':{str(p.relative_to(O)):hashlib.sha256(p.read_bytes()).hexdigest() for p in O.rglob('*') if p.is_file() and p.name!='manifest.json'}}
(O/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('20 combinations / 600 splits checked; direct region sums and fixed split reproduced.')
