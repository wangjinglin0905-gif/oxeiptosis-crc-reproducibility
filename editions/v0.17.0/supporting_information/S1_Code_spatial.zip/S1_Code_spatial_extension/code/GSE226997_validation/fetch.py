from pathlib import Path
import urllib.request,json,subprocess,sys,hashlib,time
R=Path(__file__).resolve().parents[2];O=R/'outputs/GSE226997_validation_v01_2026-11-17';O.mkdir(exist_ok=True)
sha='b2073c6e8bb7e6d8dfd15c0db6134ba4f2a8a84f';base='https://huggingface.co/datasets/jiawennnn/STimage-1K4M/resolve/'+sha+'/'
dest=Path('G:/Doc workout/_公共数据集/data/STimage/GSE226997_b2073c6')
paths=[f'Visium/coord/GSE226997_GSM{i}_coord.csv' for i in range(7089855,7089859)]+[f'Visium/image/GSE226997_GSM{i}.png' for i in range(7089855,7089859)]
for p in paths:
 target=dest/Path(p).name
 if target.exists():print('retain',target.name,flush=True);continue
 cmd=[sys.executable,'G:/Doc workout/_公共数据集/tools/fetch_data.py',base+p,'--id','GSE226997_b2073c6','--source','STimage','--register','--project','Oxeiptosis','--timeout','30','--retries','1']
 v=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace')
 (O/(target.name+'.download.log')).write_text(v.stdout,encoding='utf-8')
 print(target.name,'exit',v.returncode,'bytes',target.stat().st_size if target.exists() else 0,flush=True)
 if v.returncode:raise RuntimeError(v.stdout[-1500:])
