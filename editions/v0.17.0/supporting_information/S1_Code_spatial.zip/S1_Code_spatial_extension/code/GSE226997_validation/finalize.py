from pathlib import Path
import sys,json,hashlib
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R/'work/public_preflight_20261117/deps'))
import numpy as np,pandas as pd,scipy
from scipy.stats import rankdata
O=R/'outputs/GSE226997_validation_v01_2026-11-17';D=Path('G:/Doc workout/_公共数据集/data/STimage/GSE226997_b2073c6')
s=pd.read_csv(O/'summary.csv');reps=pd.read_csv(O/'replicates.csv');q=json.loads((O/'input_QA.json').read_text());assert len(q)==4 and len(s)==9 and len(reps)==270 and reps.split_rho.notna().all()
tab=pd.read_csv(O/'GSM7089855_member_counts_coords.csv.gz',index_col=0);tab=tab[tab.eligible];c=tab[['KEAP1','PGAM5','AIFM1','OTUD1']].to_numpy(dtype=np.int64);t=tab.total_represented_UMI.to_numpy(dtype=np.int64)
v=np.log1p(10000*c/t[:,None]);mu=v.mean(axis=0);sd=v.std(axis=0,ddof=1);rnd=np.random.default_rng(np.random.SeedSequence([20261119,7089855,0,0]));ca=rnd.binomial(c,.5);ta=ca.sum(axis=1)+rnd.binomial(t-c.sum(axis=1),.5);cb=c-ca;tb=t-ta
assert np.array_equal(ca+cb,c) and np.array_equal(ta+tb,t)
a=((np.log1p(10000*ca/ta[:,None])-mu)/sd).mean(axis=1);b=((np.log1p(10000*cb/tb[:,None])-mu)/sd).mean(axis=1)
actual=float(np.corrcoef(rankdata(a),rankdata(b))[0,1]);expected=reps[(reps['sample']=='GSM7089855')&(reps['set']=='OX4')&(reps.rep==0)].iloc[0].split_rho;assert abs(actual-expected)<1e-12
lines=['|患者样本|原始spots|合格spots|OX4共同检出|OX4拆半rho|基质拆半rho|','|---|---:|---:|---:|---:|---:|']
for z in q:
 a=s[(s['sample']==z['sample'])&(s['set']=='OX4')].iloc[0];b=s[(s['sample']==z['sample'])&(s['set']=='stromal')].iloc[0]
 lines.append(f'|{z["sample"]}|{z["n_spots"]}|{z["eligible"]}|{a.all4_positive:.2%}|{a.median_split_rho:.3f}|{b.median_split_rho:.3f}|')
(O/'table.md').write_text('\n'.join(lines),encoding='utf-8')
(O/'numerical_QA.json').write_text(json.dumps({'n_samples':4,'total_original_spots':sum(x['n_spots'] for x in q),'total_eligible_spots':sum(x['eligible'] for x in q),'n_computable_sets':9,'n_splits':270,'recreated_split_abs_difference':abs(actual-expected),'visual_QA':'four overlays inspected; no obvious global flip/offset; not histological compartment validation','numpy':np.__version__,'pandas':pd.__version__,'scipy':scipy.__version__},indent=2),encoding='utf-8')
print('\n'.join(lines));print('coverage');print(pd.read_csv(O/'member_coverage.csv').to_string(index=False))
