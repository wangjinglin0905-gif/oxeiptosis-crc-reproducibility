from pathlib import Path
import urllib.request,json,subprocess,sys,hashlib,time,concurrent.futures,datetime
R=Path(__file__).resolve().parents[2];O=R/'outputs/GSE226997_validation_v01_2026-11-17';sha='b2073c6e8bb7e6d8dfd15c0db6134ba4f2a8a84f';base='https://huggingface.co/datasets/jiawennnn/STimage-1K4M/resolve/'+sha+'/'
D=Path('G:/Doc workout/_公共数据集/data/STimage/GSE226997_b2073c6')
paths=[f'Visium/gene_exp/GSE226997_GSM{i}_count.csv' for i in range(7089855,7089859)]
req=urllib.request.Request('https://huggingface.co/api/datasets/jiawennnn/STimage-1K4M/paths-info/'+sha,data=json.dumps({'paths':paths}).encode(),headers={'Content-Type':'application/json'})
meta=json.load(urllib.request.urlopen(req,timeout=30));(O/'HF_count_file_metadata.json').write_text(json.dumps(meta,indent=2))
for item in meta:
 name=Path(item['path']).name;p=D/name;N=item['size'];expected=item['lfs']['oid'];start=time.time();chunks=D/(name+'.segments');chunks.mkdir(exist_ok=True)
 if p.exists() and p.stat().st_size==N and hashlib.sha256(p.read_bytes()).hexdigest()==expected:print('VERIFIED',name,flush=True);continue
 if p.exists():p.rename(p.with_name(p.name+'.incomplete_20261117'))
 size=4*1024*1024;events=[]
 def part(k):
  a=k*size;b=min(N-1,a+size-1);out=chunks/f'{k:04d}.part'
  if out.exists() and out.stat().st_size==b-a+1:return {'part':k,'reused':True}
  for attempt in range(3):
   try:
    u=base+item['path']+f'?download=true&segment={k}&attempt={attempt}'
    request=urllib.request.Request(u,headers={'Range':f'bytes={a}-{b}','User-Agent':'Oxeiptosis-public-data-preflight/1.0'})
    with urllib.request.urlopen(request,timeout=30) as r:
     assert r.status==206 and r.headers.get('Content-Range','').startswith(f'bytes {a}-{b}/'), 'range not honored'
     data=r.read(b-a+2);assert len(data)==b-a+1
    out.write_bytes(data);return {'part':k,'start':a,'end':b,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
   except Exception as e:
    if attempt==2:raise RuntimeError(f'{name} part {k}: {type(e).__name__} {str(e)[:150]}')
  raise RuntimeError('unreachable')
 total=(N+size-1)//size
 with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
  for event in pool.map(part,range(total)):
   events.append(event)
   if len(events)%10==0:print(name,len(events),'/',total,'seconds',round(time.time()-start),flush=True)
 h=hashlib.sha256();tmp=p.with_suffix('.merging')
 with tmp.open('wb') as f:
  for k in range(total):
   block=(chunks/f'{k:04d}.part').read_bytes();f.write(block);h.update(block)
 assert tmp.stat().st_size==N and h.hexdigest()==expected
 tmp.rename(p)
 log={'url':base+item['path'],'version':sha,'file':str(p),'size':N,'sha256':expected,'completed_at':datetime.datetime.now().astimezone().isoformat(),'seconds':time.time()-start,'method':'bounded 4MiB ranges 8 workers, Content-Range and HF LFS SHA256 validated','segments':events}
 (D/(name+'.acquisition.json')).write_text(json.dumps(log,indent=2));(O/(name+'.acquisition.json')).write_text(json.dumps(log,indent=2))
 subprocess.run([sys.executable,'G:/Doc workout/_公共数据集/tools/dataset_lib.py','register',str(p),'--id','GSE226997_b2073c6','--source','STimage','--desc','Fixed HF b2073c6; verified LFS SHA256; acquisition log adjacent'],check=True,stdout=subprocess.DEVNULL)
 print('COMPLETE',name,round(time.time()-start),flush=True)
