from pathlib import Path
import hashlib, json

root = Path(__file__).resolve().parents[2]
out = root / 'outputs/GSE226997_validation_v01_2026-11-17'
scripts = Path(__file__).parent
def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

qa = json.loads((out / 'numerical_QA.json').read_text(encoding='utf-8'))
assert qa['n_samples'] == 4 and qa['n_splits'] == 270
assert qa['recreated_split_abs_difference'] < 1e-12
files = sorted(p for p in out.iterdir() if p.is_file() and p.name != 'manifest.json')
files += sorted(scripts.glob('*.py')) + [scripts / 'contract.json', root / 'work/spatial_pilot_20261117/run.py']
manifest = {
    'date': '2026-11-17',
    'status': 'analysis_complete_and_numerically_checked; pathology_validation_not_performed',
    'source_commit': 'b2073c6e8bb7e6d8dfd15c0db6134ba4f2a8a84f',
    'input_directory': 'G:/Doc workout/_公共数据集/data/STimage/GSE226997_b2073c6',
    'source_expression_coordinate_hashes': json.loads((out / 'input_QA.json').read_text(encoding='utf-8')),
    'image_hash_record': 'image_coordinate_QA.csv',
    'file_verification_scope': 'Published derivative expression LFS SHA256 and sizes verified; no original GEO to derivative reconciliation',
    'files': [{'path': str(p.relative_to(root)), 'bytes': p.stat().st_size, 'sha256': digest(p)} for p in files],
}
(out / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
state = root / 'PROJECT_STATE.md'
marker = '## 2026-11-17：GSE226997 外部技术稳定性验证 v01完成'
entry = '''

## 2026-11-17：GSE226997 外部技术稳定性验证 v01完成

- 入口 outputs/GSE226997_validation_v01_2026-11-17/GSE226997外部技术验证报告_v01.md；四位患者GSM7089855–58，固定STimage commit b2073c6e8bb7e6d8dfd15c0db6134ba4f2a8a84f。12个输入已落统一G盘库并登记。
- 四表达文件官方LFS SHA256/长度一致，全矩阵非负整数、成员/坐标键检查通过；首次截断文件排除并留痕，分段下载后校验完成。尚未做原始GEO矩阵到衍生文件逐值核对，不能称原始计数全链追溯完成。
- 16096原生Visium spots，15502通过固定>=500表示基因总计数门槛；9个可计算样本×集合、270次拆分已运行。OX4中位rho依次0.206/0.322/0.181/0.328，全部未达0.7；基质0.937/0.894/0.856/0.778。上皮仅857完整、rho0.384；其余缺KRT19，未替代。
- OX4共同检出0.86%–6.16%，深度条件化rho0.023–0.091。原生spot非前轮64um方格，不合并效应量。技术重复分布非患者CI；不支持活性/机制验证或OX4特异缺陷，保留前轮匹配阴性结论。
- 四图所有坐标中心在界内，总体叠加未见明显翻转/错位；没有独立病理标签验证。独立重建首拆分误差5.55e-17，阶段manifest记录输出与代码哈希。
- 裁定：外部技术检验完成，独立病理趋势与普遍方法学升级未完成；停止以当前数据继续做OX4活性验证或任意参数搜索。可推进有限重构；病理分支先解决可配准独立标签与原始输入溯源，否则退出。未改原稿、未对外上传。
'''
previous = state.read_text(encoding='utf-8-sig')
if marker not in previous:
    with state.open('a', encoding='utf-8') as stream:
        stream.write(entry)
assert (out / 'GSE226997外部技术验证报告_v01.md').is_file()
print(json.dumps({'status': 'closed_out', 'manifest_files': len(files), 'samples': qa['n_samples'], 'splits': qa['n_splits']}, ensure_ascii=False))
