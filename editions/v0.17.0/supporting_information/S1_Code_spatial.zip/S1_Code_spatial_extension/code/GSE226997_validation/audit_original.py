from pathlib import Path
import sys,json,hashlib,collections
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'work/public_preflight_20261117/deps'))
import numpy as np,pandas as pd,h5py
from scipy.sparse import csc_matrix
O=ROOT/'outputs/GSE226997_provenance_pathology_v01_2026-11-17';D=Path('G:/Doc workout/_公共数据集/data/GEO/GSE226997/original_prefix_v01');S=Path('G:/Doc workout/_公共数据集/data/STimage/GSE226997_b2073c6')
rows=[]
for n in range(7089855,7089859):
 sid=f'GSM{n}';p=D/sid/'filtered_feature_bc_matrix.h5'
 if not p.exists():print('MISSING',sid);continue
 with h5py.File(p) as f:
  m=f['matrix'];shape=tuple(int(v) for v in m['shape'][:]);names=m['features']['name'][:].astype(str);ens=m['features']['id'][:].astype(str);barcodes=m['barcodes'][:].astype(str)
  x=csc_matrix((m['data'][:],m['indices'][:],m['indptr'][:]),shape=shape)
  extra={'feature_types':list(set(m['features']['feature_type'][:].astype(str))),'genomes':list(set(m['features']['genome'][:].astype(str))),'target_sets':list(m['features']['target_sets']) if 'target_sets' in m['features'] else []}
 frame=pd.read_csv(S/f'GSE226997_{sid}_count.csv',index_col=0)
 actualbars=np.array([s.removeprefix(f'GSE226997_{sid}_') for s in frame.index]);assert np.array_equal(actualbars,barcodes)
 assert frame.shape==(shape[1],shape[0])
 namechanges=[{'column':i,'original':str(a),'derivative':str(b),'ensembl':str(ens[i])} for i,(a,b) in enumerate(zip(names,frame.columns)) if a!=b]
 mismatches=0;maxdiff=0
 for a in range(0,len(barcodes),256):
  original=x[:,a:a+256].T.toarray();derivative=frame.iloc[a:a+256].to_numpy();diff=abs(original.astype(np.int64)-derivative.astype(np.int64));mismatches+=int(np.count_nonzero(diff));maxdiff=max(maxdiff,int(diff.max()))
 total=np.asarray(x.sum(axis=0)).ravel().astype(np.int64);prev=pd.read_csv(ROOT/f'outputs/GSE226997_validation_v01_2026-11-17/{sid}_member_counts_coords.csv.gz',index_col=0)
 assert np.array_equal(total,prev.total_represented_UMI.to_numpy())
 members={g:[{'index':int(j),'id':str(ens[j])} for j in np.where(names==g)[0]] for g in ['KEAP1','PGAM5','AIFM1','OTUD1','EPCAM','KRT8','KRT18','KRT19','COL1A1','COL1A2','COL3A1','DCN']}
 row={'sample':sid,'original_genes':shape[0],'original_spots':shape[1],'unique_original_symbols':len(set(names)),'barcode_order_identical':True,'count_cells_compared':int(frame.size),'nonidentical_count_cells':mismatches,'max_abs_count_difference':maxdiff,'denominator_identical_to_original_filtered_h5':True,'name_changes':namechanges,'members':members,'original_h5_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),**extra}
 rows.append(row);print(json.dumps(row),flush=True)
 pd.DataFrame({'id':ens,'original_symbol':names,'STimage_symbol':frame.columns}).to_csv(O/f'{sid}_feature_mapping.csv',index=False)
(O/'original_vs_STimage_audit.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
print('COMPARED',sum(r['count_cells_compared'] for r in rows),'MISMATCHES',sum(r['nonidentical_count_cells'] for r in rows),flush=True)
