from pathlib import Path
import sys,re,json,hashlib,shutil,difflib
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'work/public_preflight_20261117/deps'))
import pandas as pd
O=ROOT/'outputs/Oxeiptosis_postrejection_v13_working_2026-11-17';O.mkdir(exist_ok=True)
base=ROOT/'outputs/Oxeiptosis_PLOS_ONE_v12_technical_2026-10-03/manuscript_PLOS_v12.md';original=base.read_text(encoding='utf-8-sig');text=original
def once(a,b):
 global text
 assert text.count(a)==1,(a[:90],text.count(a));text=text.replace(a,b)
oldtitle=text.splitlines()[0];once(oldtitle,'Interpreting an oxeiptosis-associated transcript score in colorectal cancer: clinical benchmarks and spatial measurement limits')
once('Short title: Oxeiptosis-associated transcript score in colorectal cancer','Short title: Clinical and spatial interpretation of an OX4 transcript score')
abstract='''Background: A pathway-associated gene list does not by itself define a calibrated measure of pathway activity. We evaluated the clinical associations, transcriptional context and spatial measurement properties of an equally weighted KEAP1–PGAM5–AIFM1–OTUD1 score (OX4) in colorectal cancer.

Methods: The original bulk analysis included TCGA-COADREAD, GSE39582 and GSE17538, with 367, 561 and 232 patients, respectively. We compared adjusted overall-survival associations with matched four-gene backgrounds and examined correlated transcript references. A subsequent exploratory extension assessed count-split stability in five GSE280315 tissue sections and four GSE226997 patients. Spatial comparisons included expression-and-detection-matched sets and prespecified stromal and epithelial marker constructs. The GSE226997 derivative matrices were checked against the original deposited processed matrices.

Results: Adjusted OX4 hazard ratios were 0.939 (95% confidence interval 0.753–1.171), 0.939 (0.809–1.091) and 1.175 (0.935–1.476). Their absolute log-effect sizes lay near the middle of the specified matched backgrounds. OX4 shared variation with mitochondrial, proliferation and NRF2-related transcript references. At the primary 64-μm scale in GSE280315, median split-half correlations were approximately 0.25–0.50, but OX4 ranked at the 66th–95th percentiles of expression-and-detection-matched backgrounds. Native-spot correlations in GSE226997 were 0.181–0.328, versus 0.778–0.937 for the stromal construct. Three original GSE226997 matrices lacked KRT19, precluding the complete epithelial construct. All 294,437,824 compared matrix entries agreed between the deposited and derivative files.

Conclusions: Clinical association, transcriptional context and technical stability constrain different aspects of score interpretation. Limited absolute spatial stability did not imply an OX4-specific deficit relative to matched gene sets. This case study supports explicit construction and comparator reporting; it does not establish the score as a measure of oxeiptosis activity.'''
a=text.index('Background:');b=text.index('\n\nKeywords',a);text=text[:a]+abstract+text[b:]
once('Keywords oxeiptosis; colorectal cancer; gene expression; gene-set scoring; overall survival; reproducibility','Keywords oxeiptosis; colorectal cancer; gene-set scoring; spatial transcriptomics; measurement stability; matched controls')
old='We evaluated an investigator-assembled, equally weighted four-gene score in three colorectal cancer cohorts. The primary question was whether its overall-survival association was consistent after adjustment for age, sex and stage. We then examined member selection, matched random-set backgrounds, platform coverage and correlated transcript references. A targeted source audit established how published oxeiptosis-related lists had been used. The study combines clinical benchmarking with construction diagnostics and a public model-reproduction package, including 108 cohort-specific reference-pair comparisons and 6,000 background models.'
new='''We evaluated an investigator-assembled, equally weighted four-gene score in colorectal cancer. The original bulk analysis asked whether its overall-survival association was consistent after adjustment for age, sex and stage, and examined member selection, matched backgrounds and correlated transcript references. We subsequently extended the study to spatial data to distinguish absolute technical stability from performance relative to similarly measured gene sets. These analyses address complementary measurement questions; the spatial extension was added after the bulk results and was not a prospectively registered validation study. A targeted source audit distinguishes published gene lists from the constructs built from them.'''
once(old,new)
methods='''Exploratory spatial extension and input provenance

The spatial extension was conducted after completion of the bulk analysis. It used five GSE280315 Visium HD sections (P1CRC, P2CRC, P5CRC, P3NAT and P5NAT) from the published colorectal study [18] and four GSE226997 patients [19]. The five HD sections represent three tumour and two normal-adjacent sections; their labels indicate four donors, including a tumour/normal-adjacent pair. Sections, regions and technical splits were not treated as independent patients. GSE226997 expression tables, coordinates and H&E images were obtained from STimage-1K4M [20], fixed at repository commit b2073c6e8bb7e6d8dfd15c0db6134ba4f2a8a84f. All four complete filtered_feature_bc_matrix.h5 files were recovered from bounded prefixes of the original GEO archives. We compared every count entry, feature position and barcode with the derivative tables, documented duplicate-symbol suffixes, and verified the depth denominator. We did not reprocess FASTQ files or download and validate the complete archives.

For GSE280315, 8-μm bins were summed into square regions of 32, 64, 128 and 256 μm, with 64 μm designated as the primary scale before the stability analyses. A region required at least 50% of its grid bins to be represented and at least 500 total counts. GSE226997 was analysed at native Visium spots with at least 500 counts across the features represented in each matrix. The platforms and sampling geometries were analysed separately. Zero member counts were retained; joint detection of all four members was a reported property, not an inclusion criterion.

Spatial OX4 was defined as the mean of four gene-wise z scores after log1p(CP10K), using each section's eligible units as the reference and sample SD for each gene. This spatial analogue was not a transfer of the bulk-score calibration. For each technical split, member counts and counts for the remaining represented genes were allocated between two halves by binomial sampling with probability 0.5. Each half used its own total count for normalization and the full-data gene means and SDs. We reported Spearman correlations between the two half-scores and, as a sensitivity analysis, correlations between rank residuals after conditioning on both half-depth ranks. Working stability thresholds were a median correlation of at least 0.7 and a 10th percentile of at least 0.6; these were operational decision rules, not established biological cutoffs. Depth associations and joint detection were reported separately. The initial GSE280315 screen additionally required at least 50 regions, joint detection of at least 80% and absolute score–depth correlation no greater than 0.5 for its composite feasibility gate (S3 Text).

The GSE280315 scale pilot used 30 splits per section and scale. The matched comparison used 100 unique four-gene sets per section, each evaluated with 10 splits, alongside OX4 and a stromal construct. Candidates matched each OX4 member's mean CP10K within a factor of two and detection rate within 0.05. Original members, reference members, duplicate symbols and MT-/RPL/RPS-prefixed genes were excluded. Up to 30 nearest candidates per member were retained; each pool required at least 10 candidates. The background percentile was the fraction of matched sets with a lower median split correlation than OX4, not a P value. Matching did not control all covariance or spatial structure. GSE226997 used 30 splits per complete construct and did not repeat the matched-set analysis. Seeds, full matching rules and provenance are in S3 Text and S28–S31 Tables.

The predefined stromal construct comprised COL1A1, COL1A2, COL3A1 and DCN; the epithelial construct comprised EPCAM, KRT8, KRT18 and KRT19. These investigator-defined marker averages served as technical references, not mechanism-positive controls or independently validated histological labels. Incomplete constructs were not scored. Image–coordinate overlays were checked for gross alignment. No independent human pathology annotation was performed. The published GSE226997 compartment definitions combined expression clustering and H&E morphology [19] and were not used as expression-independent ground truth. Technical-split distributions were reported descriptively, without patient-level significance tests or pooled cross-platform effect estimates.'''
once('\n\nEthics statement\n','\n\n'+methods+'\n\nEthics statement\n')
once('Clinical trial number: not applicable.','The spatial extension accessed GSE280315 and GSE226997 resources for research on 17 November 2026. Acquisition records distinguish the STimage derivative files from the subsequently retrieved original GEO processed matrices.\n\nClinical trial number: not applicable.')
once('Bibliographic identity and claim-support scope for the cited references are recorded in S27 Table.','Bibliographic identity and claim-support scope for the original bulk-manuscript references are recorded in S27 Table. The added spatial references and the reference-number crosswalk are recorded in S3 Text and the v13 revision record.')
once('S27 Table. Bibliographic identity, publication-notice checks and claim-support scope for the 17 main-manuscript references.','S27 Table. Retained bibliographic audit of the 17 original bulk-manuscript references. The v13 reference-number crosswalk maps these earlier identifiers to the revised bibliography; added sources are documented separately in S3 Text.')
M=ROOT/'outputs/GSE280315_matched_controls_v01_2026-11-17';V=ROOT/'outputs/GSE226997_validation_v01_2026-11-17';P=ROOT/'outputs/GSE226997_provenance_pathology_v01_2026-11-17'
mc=pd.read_csv(M/'comparison.csv');sv=pd.read_csv(V/'summary.csv');prov=json.loads((P/'original_vs_STimage_audit.json').read_text())
t4=['Table 4. Spatial count-split stability relative to matched backgrounds in GSE280315.','','| Section | OX4 median rho | Matched-set median rho | OX4 percentile | Stromal median rho |','| --- | ---: | ---: | ---: | ---: |']
for _,r in mc.iterrows():t4.append(f'| {r["sample"]} | {r.OX4_rho:.3f} | {r.matched_median:.3f} | {r.OX4_percentile:.0f} | {r.stromal_rho:.3f} |')
t4+=['','The primary 64-μm analysis used 10 splits per construct and 100 matched sets per section. Percentiles are descriptive background ranks. The initial 30-split pilot used a separate random seed; its results are retained in S28 Table. CRC, colorectal cancer; NAT, normal-adjacent tissue.']
t5=['Table 5. Native-spot technical stability in GSE226997.','','| Sample | Eligible spots | OX4 joint detection, % | OX4 median rho | OX4 P10–P90 | Stromal median rho |','| --- | ---: | ---: | ---: | ---: | ---: |']
for sid in sv['sample'].unique():
 a=sv[(sv['sample']==sid)&(sv['set']=='OX4')].iloc[0];b=sv[(sv['sample']==sid)&(sv['set']=='stromal')].iloc[0]
 t5.append(f'| {sid} | {int(a.n_spots)} | {100*a.all4_positive:.2f} | {a.median_split_rho:.3f} | {a.p10:.3f}–{a.p90:.3f} | {b.median_split_rho:.3f} |')
t5+=['','Each complete construct used 30 splits. Joint detection was calculated among eligible spots and was not an inclusion filter. P10–P90 describes technical repetitions, not a patient-level confidence interval.']
results='''Spatial OX4 had limited absolute stability without an additional deficit against matched sets

In GSE280315, the 30-split pilot yielded median OX4 correlations of 0.358, 0.501, 0.253, 0.358 and 0.285 at 64 μm for P1CRC, P2CRC, P5CRC, P3NAT and P5NAT, respectively. All were below the working median threshold. None of the 20 section-by-scale combinations met every composite feasibility condition. P2CRC reached a median correlation of 0.822 at 256 μm, but its score–depth correlation was 0.729 (S28 Table).

In the separately seeded matched comparison, OX4 ranked at the 66th–95th percentiles of the matched backgrounds and exceeded the matched-set median in every section (Table 4). After conditioning on half-depth ranks, OX4 ranked at the 31st–90th percentiles, with no section below the 10th percentile. The predefined criterion for an additional deficit, at least three of five sections below the matched 10th percentile, was therefore not met. Stromal median correlations were 0.955–0.964 in tumour sections and 0.649 and 0.845 in the two normal-adjacent sections. The five supplied matrices lacked the exact KRT18 feature symbol, so the complete epithelial construct was not calculated. These findings separate limited absolute stability from evidence of an OX4-specific deficit.

'''+ '\n'.join(t4)+'''

Original-file verification supported the GSE226997 technical replication

All 294,437,824 count entries agreed between the four GEO-deposited filtered HDF5 matrices and their STimage tables. Removing the STimage sample prefix gave identical barcode order. The total-count denominator also agreed for every spot. Duplicate symbols received suffixes without count aggregation; these affected neither OX4 nor the predefined reference members. Three original matrices contained 17,944 features and lacked KRT19; GSM7089857 contained 19,144 features and included KRT19. Thus, the epithelial coverage gap preceded the STimage representation (S31 Table).

Of 16,096 native spots, 15,502 met the depth criterion. OX4 median split correlations were 0.181–0.328, with joint member detection in 0.86%–6.16% of eligible spots (Table 5). Conditioning on half-depth ranks reduced the median correlations to 0.023–0.091; full-score correlations with depth were 0.388–0.534. Stromal median correlations were 0.778–0.937. The only complete epithelial construct, in GSM7089857, had median correlation 0.384. All available results, including the low epithelial stability, were retained (S30 Table).

'''+ '\n'.join(t5)+'''

All four image–coordinate overlays passed the gross alignment inspection, but no independent histological compartment evaluation was performed. These analyses establish correspondence of the processed expression inputs and characterize technical splitting behaviour. They do not establish biological reproducibility between sections or spatial localization of oxeiptosis activity.'''
once('\n\nDiscussion\n','\n\n'+results+'\n\nDiscussion\n')
once('This study integrates survival benchmarking, transcript-context analysis and source tracing for a defined four-gene score. Across three colorectal cancer cohorts, clinically adjusted OX4 estimates differed in direction and fell near the middle of the specified matched backgrounds. The results characterise the behaviour of this expression construct while identifying two practical requirements for its interpretation: explicit score construction and explicit comparator structure.','This study separates three questions that arise when a mechanistically motivated gene list becomes a transcript score: whether it associates with a clinical outcome, what broader expression variation it shares, and how consistently it can be measured in a specified assay. OX4 lacked a consistent adjusted survival association across the three bulk cohorts. Its spatial analogue had limited absolute count-split stability, yet did not perform worse than expression-and-detection-matched sets in the tested HD sections. Considering both absolute and relative benchmarks changes the interpretation of a low-stability result.')
extra='''The spatial extension adds a measurement diagnostic to the clinical analysis. Relative performance against low-detection gene sets cannot establish that a score is sufficiently stable for a biological interpretation. Conversely, a low absolute correlation alone does not show that the selected pathway members are uniquely problematic. The stromal construct demonstrates that the same processing scheme can recover more stable signals, but differences in abundance and covariance prevent it from serving as a matched mechanism control. The low epithelial correlation in the one complete GSE226997 sample further limits a simple contrast between OX4 and all other marker constructs.

Original-file tracing resolved a separate uncertainty: the GSE226997 count representation did not introduce the missing KRT19 feature or alter the measured counts. Feature universes and archived processing metadata nevertheless differed among patients. Such differences should be reported alongside score coverage rather than interpreted as biological absence. Independent morphology-defined labels could test whether composition contributes to score behaviour, but the original study's expression-assisted compartments cannot supply that independent test [19].'''
once('\n\nThe combined analyses identify reporting practices', '\n\n'+extra+'\n\nThe combined analyses identify reporting practices')
once('The archived model inputs and verification scripts make these comparisons reproducible. These are practical recommendations from a case study, rather than a consensus standard.','The archived bulk-model inputs and verification scripts make the original comparisons reproducible; the spatial extension is documented separately. These are practical recommendations from a case study, rather than a consensus standard or a new validated scoring algorithm.')
once('\n\nConclusions\n','''

The spatial extension was exploratory and followed the bulk results. It included few patients, different sampling geometries and targeted feature universes. Random count splitting reduces the counts available to each half and measures a conditional technical property, not repeat-section or biological reproducibility. The split halves share the full-data standardization reference and arise from one observed matrix. Depth can reflect tissue composition as well as technical yield, so conditional correlations do not identify causal artifacts. Spatial matched backgrounds controlled marginal expression and detection but not all gene–gene or spatial covariance. GSE226997 did not include a separate matched-set analysis, independent pathology labels or a functional death readout. Original filtered matrices were verified, but complete sequencing archives and original high-resolution image transformations were not reconstructed.

Conclusions
''')
oldcon='Benchmarking across three colorectal cancer cohorts showed that the equally weighted KEAP1–PGAM5–AIFM1–OTUD1 score had imprecise adjusted survival associations and shared variation with broader transcript programmes. Its observed effect sizes fell near the middle of both specified matched backgrounds. The study provides a reproducible example of assessing clinical association together with score construction and comparator structure. Functional calibration remains necessary before treating this transcript score as a measurement of oxeiptosis activity.'
once(oldcon,'Clinical and spatial analyses placed distinct limits on the interpretation of OX4. Bulk associations were imprecise and shared broader transcriptional variation; spatial count-split stability was limited, without an additional deficit against the tested matched backgrounds. Explicit feature coverage, assay-specific construction and appropriate comparators help distinguish these findings from claims about pathway function. OX4 remains a transcript construct requiring functional calibration before interpretation as oxeiptosis activity.')
once('The present submission revises the text and documentation without changing the archived analytical results.','The published archive covers the earlier bulk analysis and does not yet contain the spatial extension described in this working draft. The bulk analytical results are unchanged. Spatial analysis tables, source-file mappings, code and checksums are retained in the local v13 package; their public release identifier must be added before a new submission.')
once('The original datasets are available from GEO (GSE39582, GSE17538 and GSE71187)', 'The original datasets are available from GEO (GSE39582, GSE17538, GSE71187, GSE280315 and GSE226997)')
once('GSE39582, GSE17538 and GSE71187, whose publicly deposited data made this analysis possible','GSE39582, GSE17538, GSE71187, GSE280315 and GSE226997, and the STimage-1K4M contributors, whose publicly deposited data made this analysis possible')
newrefs='''18. Faria de Oliveira M, Romero JP, Chung M, Williams SR, Gottscho AD, Gupta A, et al. High-definition spatial transcriptomic profiling of immune cell populations in colorectal cancer. Nat Genet. 2025;57(6):1512-1523. doi: 10.1038/s41588-025-02193-3.

19. Park SS, Lee YK, Choi YW, Lim SB, Park SH, Kim HK, et al. Cellular senescence is associated with the spatial evolution toward a higher metastatic phenotype in colorectal cancer. Cell Rep. 2024;43(3):113912. doi: 10.1016/j.celrep.2024.113912.

20. Chen J, Zhou M, Wu W, Zhang J, Li Y, Li D. STimage-1K4M: A histopathology image-gene expression dataset for spatial transcriptomics. Advances in Neural Information Processing Systems. 2024;37. doi: 10.52202/079017-1129.'''
once('\n\nSupporting information\n','\n\n'+newrefs+'\n\nSupporting information\n')
text+='''

S3 Text. Exploratory spatial extension: complete rules, provenance audit, source roles and limits of pathology interpretation.

S28 Table. All 20 GSE280315 section-by-scale stability summaries.

S29 Table. All 510 GSE280315 matched-comparison construct summaries.

S30 Table. All nine calculable GSE226997 construct summaries.

S31 Table. Four-sample original-processed-matrix versus STimage provenance audit.
'''
# Preserve numerical bulk Results and Tables 1-3, then renumber references by first use.
bulk_start='Overall-survival estimates varied in direction across cohorts'
bulk_end='Spatial OX4 had limited absolute stability'
assert original.split(bulk_start)[1].split('\n\nDiscussion')[0]==text.split(bulk_start)[1].split('\n\n'+bulk_end)[0]
body,rest=text.split('\n\nReferences\n\n');refs,support=rest.split('\n\nSupporting information\n',1)
entries={int(m.group(1)):m.group(2).strip() for m in re.finditer(r'(?ms)^(\d+)\. (.*?)(?=^\d+\. |\Z)',refs)}
pattern=r'\[(\d+(?:[–,\-]\s*\d+)*)\]';order=[]
def expand(s):
 vals=[]
 for part in s.split(','):
  nums=re.split('[–-]',part.strip());vals.extend(range(int(nums[0]),int(nums[-1])+1))
 return vals
for match in re.finditer(pattern,body):
 for n in expand(match.group(1)):
  if n not in order:order.append(n)
assert set(order)==set(entries)==set(range(1,21))
mapping={n:i+1 for i,n in enumerate(order)}
body=re.sub(pattern,lambda m:'['+', '.join(str(mapping[n]) for n in expand(m.group(1)))+']',body)
text=body+'\n\nReferences\n\n'+'\n\n'.join(f'{mapping[n]}. {entries[n]}' for n in order)+'\n\nSupporting information\n'+support
(O/'manuscript_v13_working_2026-11-17.md').write_text(text,encoding='utf-8')
(O/'v12_to_v13.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True),text.splitlines(True),fromfile='v12',tofile='v13')),encoding='utf-8')
pd.DataFrame([{'old_reference':n,'v13_reference':mapping[n],'entry':entries[n],'current_check':'new source bibliographic identity and relevant source role verified' if n>17 else 'retained baseline; not reaudited this turn'} for n in order]).to_csv(O/'reference_number_crosswalk.csv',index=False)
for src,dst in [(ROOT/'outputs/GSE280315_region_pilot_v01_2026-11-17/summary.csv','S28_Table_spatial_scales.csv'),(M/'summary.csv','S29_Table_spatial_matched_sets.csv'),(V/'summary.csv','S30_Table_external_spatial.csv')]:shutil.copyfile(src,O/dst)
pd.DataFrame([{k:r[k] for k in ['sample','original_genes','original_spots','count_cells_compared','nonidentical_count_cells','max_abs_count_difference','barcode_order_identical','denominator_identical_to_original_filtered_h5','original_h5_sha256']} for r in prov]).to_csv(O/'S31_Table_input_provenance.csv',index=False)
for fname,rows in [('S28_Table_spatial_scales.csv',20),('S29_Table_spatial_matched_sets.csv',510),('S30_Table_external_spatial.csv',9),('S31_Table_input_provenance.csv',4)]:assert len(pd.read_csv(O/fname))==rows
for caption in ['Table 1.','Table 2.','Table 3.']:
 a=original.index(caption);b=original.index('\n\n',a);label=original[a:b];assert label in text
 orig_table=re.search(r'\n\|.*?(?=\n\n)',original[b:],re.S).group();assert orig_table in text
assert 'Clinical trial number: not applicable.' in text and 'Department of Digestive Disease' in text
assert 'The present submission revises the text and documentation without changing the archived analytical results.' not in text
qa={'baseline_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256((O/'manuscript_v13_working_2026-11-17.md').read_bytes()).hexdigest(),'bulk_results_preserved_before_reference_renumbering':True,'tables_1_3_preserved':True,'references':len(entries),'new_supporting_table_rows':[20,510,9,4],'original_matrix_entries_compared':sum(r['count_cells_compared'] for r in prov),'count_mismatches':sum(r['nonidentical_count_cells'] for r in prov),'status':'scientific working draft; not submission package; no human pathology evaluation; spatial release pending'}
(O/'revision_QA.json').write_text(json.dumps(qa,indent=2),encoding='utf-8');print(json.dumps(qa),flush=True)
