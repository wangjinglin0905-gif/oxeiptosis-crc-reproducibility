from pathlib import Path
import hashlib,json,csv,zipfile
ROOT=Path(__file__).resolve().parents[2]
P=ROOT/'outputs/GSE226997_provenance_pathology_v01_2026-11-17';O=ROOT/'outputs/Oxeiptosis_postrejection_v13_working_2026-11-17'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
items=[
 ('bulk_baseline','outputs/Oxeiptosis_PLOS_ONE_v12_technical_2026-10-03/manuscript_PLOS_v12.md','frozen; no recalculation'),
 ('HD_scale_summary','outputs/GSE280315_region_pilot_v01_2026-11-17/summary.csv','20 section-scale summaries'),
 ('HD_scale_repetitions','outputs/GSE280315_region_pilot_v01_2026-11-17/split_replicates.csv','600 technical repetitions'),
 ('HD_matched_summary','outputs/GSE280315_matched_controls_v01_2026-11-17/summary.csv','510 construct summaries'),
 ('HD_matched_repetitions','outputs/GSE280315_matched_controls_v01_2026-11-17/replicates.csv','5100 technical repetitions'),
 ('HD_balance','outputs/GSE280315_matched_controls_v01_2026-11-17/selected_match_balance.csv','2000 member-level matching records'),
 ('external_summary','outputs/GSE226997_validation_v01_2026-11-17/summary.csv','9 complete constructs'),
 ('external_repetitions','outputs/GSE226997_validation_v01_2026-11-17/replicates.csv','270 technical repetitions'),
 ('original_provenance','outputs/GSE226997_provenance_pathology_v01_2026-11-17/original_vs_STimage_audit.json','4 original deposited processed matrices; zero count differences'),
 ('scale_code','work/spatial_pilot_20261117/run.py','existing implementation'),
 ('matched_code','work/matched_controls_20261117/run.py','existing implementation'),
 ('external_code','work/GSE226997_validation_20261117/analyze.py','existing implementation'),
 ('input_audit_code','work/GSE226997_validation_20261117/audit_original.py','original count audit'),
 ('revision_code','work/GSE226997_validation_20261117/build_v13.py','rebuilds v13 from v12 and frozen CSVs')]
with (O/'spatial_artifact_index.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(['role','absolute_path','sha256','scope'])
 for role,relative,scope in items:
  p=ROOT/relative;assert p.is_file();w.writerow([role,str(p),sha(p),scope])
audit=json.loads((P/'original_vs_STimage_audit.json').read_text());assert len(audit)==4
assert all(x['nonidentical_count_cells']==0 and x['barcode_order_identical'] and x['denominator_identical_to_original_filtered_h5'] for x in audit)
for row in audit:
 assert all(v['original'] in {'TBCE','HSPA14','MATR3','GGT1'} and v['derivative']==v['original']+'-1' for v in row['name_changes'])
for folder in [P,O]:
 files=[p for p in sorted(folder.rglob('*')) if p.is_file() and p.name!='manifest_v01.json' and p.suffix!='.zip']
 (folder/'manifest_v01.json').write_text(json.dumps({'date':'2026-11-17','files':[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files]},ensure_ascii=False,indent=2),encoding='utf-8')
with zipfile.ZipFile(O/'v13_working_text_and_new_tables.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(O.iterdir()):
  if p.is_file() and p.suffix!='.zip':z.write(p,p.name)
state=ROOT/'PROJECT_STATE.md';marker='## 2026-11-17：原始溯源、病理裁定及退稿后v13工作稿'
entry='''

## 2026-11-17：原始溯源、病理裁定及退稿后v13工作稿

- 已按1→2→3顺序执行。原始溯源报告入口 outputs/GSE226997_provenance_pathology_v01_2026-11-17/步骤1-2溯源与病理裁定_v01.md；整合稿入口 outputs/Oxeiptosis_postrejection_v13_working_2026-11-17/修订裁定与阅读入口_v13.md。
- 四份GEO归档各读取64MiB压缩前缀，取得完整H5及features/barcodes，G盘统一库已登记。共294437824计数值与STimage完全一致，barcode顺序、特征位置与总计数分母一致；重复符号后缀不影响目标或参照。无需重跑前轮统计。未验证全归档CRC或FASTQ流程。
- 三份KRT19缺失已追溯至原H5及features.tsv；四H5均含Human Transcriptome Probe Set。H5软件属性为1.3.1/1.3.0，GEO文本为1.0.0且注释版本文字不一致，保留差异而不补造确定版本。
- 原论文Visium方法明确中心/侵袭前沿/间质由表达聚类结合H&E定义，非纯形态独立标签。Data S1未取得，出版商端点403。四图原生裁剪与盲化可行性包已做技术核验，无实际人工病理评分。
- 作者本轮明确“暂不安排，先按已有证据修订”；本轮独立病理分支停止，不生成替代标签。有限重构v13英文Markdown工作稿完成：新增空间方法/结果/主表4–5、S3 Text与S28–S31，修订题目/摘要/讨论/结论/可得性，bulk Results及表1–3保持。引用20条按首次出现排序，旧号映射保存，旧17文献未重新全量审计。
- v13为工作稿，不是投稿包：未做DOCX排版/新期刊适配/新空间公开归档/全量图文终审。旧v12及GitHub/Zenodo不变，无外部发送或投稿。
- 作者额外允许确需整包时下载到I盘并考虑“公共数据库2”。本轮矩阵需求已满足，无需41.2GB整包；未新建第二公共主库或迁移数据。
'''
if marker not in state.read_text(encoding='utf-8-sig'):
 with state.open('a',encoding='utf-8') as f:f.write(entry)
print(json.dumps({'stage1':'original_processed_matrix_audit_complete','stage2':'independence_audit_complete; human_annotation_not_performed_by_author_decision','stage3':'v13_working_manuscript_complete','zip':str(O/'v13_working_text_and_new_tables.zip')},ensure_ascii=False))
