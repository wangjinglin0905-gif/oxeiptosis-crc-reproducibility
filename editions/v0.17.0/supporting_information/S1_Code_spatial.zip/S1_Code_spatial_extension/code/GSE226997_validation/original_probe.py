from pathlib import Path
import urllib.request,tarfile,zlib,io,json,hashlib,time,concurrent.futures,datetime,subprocess,sys
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'outputs/GSE226997_provenance_pathology_v01_2026-11-17'
OUT.mkdir(exist_ok=True)
DEST=Path('G:/Doc workout/_公共数据集/data/GEO/GSE226997/original_prefix_v01')
DEST.mkdir(parents=True,exist_ok=True)
def sha(b): return hashlib.sha256(b).hexdigest()
def run(i):
 sid=f'GSM{7089854+i}'; name=f'{sid}_Ajou_Visium_P{i}.tar.gz';u=f'https://ftp.ncbi.nlm.nih.gov/geo/samples/GSM7089nnn/{sid}/suppl/{name}'
 d=DEST/sid;d.mkdir(exist_ok=True);chunk=2*1024*1024;parts=d/'prefix_parts';parts.mkdir(exist_ok=True);events=[]
 def part(k):
  a=k*chunk;b=a+chunk-1;p=parts/f'{k:03d}.part'
  if p.exists() and p.stat().st_size==chunk:return p
  for attempt in range(3):
   try:
    req=urllib.request.Request(u+f'?part={k}&attempt={attempt}',headers={'Range':f'bytes={a}-{b}'})
    with urllib.request.urlopen(req,timeout=35) as r:
     assert r.status==206 and r.headers.get('Content-Range','').startswith(f'bytes {a}-{b}/')
     data=r.read(chunk+1);assert len(data)==chunk
     events.append({'part':k,'content_range':r.headers['Content-Range'],'last_modified':r.headers.get('Last-Modified'),'sha256':sha(data)})
    p.write_bytes(data);return p
   except Exception:
    if attempt==2:raise
 with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool: paths=list(pool.map(part,range(32)))
 prefix=b''.join(p.read_bytes() for p in paths);de=zlib.decompressobj(31);raw=de.decompress(prefix,512*1024*1024)
 assert len(raw)<512*1024*1024,'decompression bound'
 members=[];extracted=[]
 f=tarfile.open(fileobj=io.BytesIO(raw),mode='r:')
 try:
  for m in f:
   complete=m.offset_data+m.size<=len(raw)
   members.append({'name':m.name,'size':m.size,'offset':m.offset_data,'complete_in_prefix':complete})
   if complete and m.isfile() and ('Fastq/' not in m.name) and m.size<100*1024*1024:
    payload=f.extractfile(m).read();p=d/Path(m.name).name
    if p.exists():assert sha(p.read_bytes())==sha(payload)
    else:p.write_bytes(payload)
    extracted.append({'file':str(p),'member':m.name,'size':len(payload),'sha256':sha(payload)})
   if not complete:break
 except tarfile.ReadError as e: members.append({'parse_stop':str(e)})
 log={'sample':sid,'url':u,'accessed_at':datetime.datetime.now().astimezone().isoformat(),'scope':'64MiB compressed prefix only; not full gzip CRC or complete archive verification','prefix_sha256':sha(prefix),'prefix_bytes':len(prefix),'inflated_bytes':len(raw),'gzip_eof':de.eof,'events':events,'members':members,'extracted':extracted}
 (d/'prefix_acquisition.json').write_text(json.dumps(log,indent=2),encoding='utf-8');(OUT/f'{sid}_original_prefix.json').write_text(json.dumps(log,indent=2),encoding='utf-8')
 print(sid,json.dumps(members),flush=True)
 return log
logs=[]
for i in range(1,5):
 try:logs.append(run(i))
 except Exception as e:
  print('FAILED',i,type(e).__name__,str(e),flush=True);logs.append({'sample':f'GSM{7089854+i}','error':str(e)})
(OUT/'original_acquisition_summary.json').write_text(json.dumps(logs,indent=2),encoding='utf-8')
for log in logs:
 for item in log.get('extracted',[]):
  subprocess.run([sys.executable,'G:/Doc workout/_公共数据集/tools/dataset_lib.py','register',item['file'],'--id','GSE226997_original_prefix_v01','--source','GEO','--desc','Complete member from HTTP-range original archive prefix; archive not fully downloaded; acquisition log adjacent'],check=True,stdout=subprocess.DEVNULL)
