from pathlib import Path
import sys,json,hashlib
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R/'work/public_preflight_20261117/deps'))
import pandas as pd,numpy as np,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image
D=Path('G:/Doc workout/_公共数据集/data/STimage/GSE226997_b2073c6');O=R/'outputs/GSE226997_validation_v01_2026-11-17'
fig,axs=plt.subplots(4,2,figsize=(9,16),layout='constrained');rows=[]
for k,i in enumerate(range(7089855,7089859)):
 sid='GSM'+str(i);p=D/f'GSE226997_{sid}.png';im=Image.open(p);im.verify();im=Image.open(p);coord=pd.read_csv(D/f'GSE226997_{sid}_coord.csv',index_col=0)
 w,h=im.size;inside=(coord.xaxis.between(0,w-1)&coord.yaxis.between(0,h-1));rows.append({'sample':sid,'width':w,'height':h,'n_coords':len(coord),'centers_inside':int(inside.sum()),'image_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'radius_pixels':float(coord.r.median())})
 for j in range(2):axs[k,j].imshow(im);axs[k,j].axis('off');axs[k,j].set_title(f'{sid} '+('H&E' if j==0 else 'coordinate overlay'))
 axs[k,1].scatter(coord.xaxis,coord.yaxis,s=1,alpha=.4,c='cyan');axs[k,0].text(-.03,1.01,chr(97+k),transform=axs[k,0].transAxes,fontweight='bold')
fig.savefig(O/'coordinate_overlay_QA.png',dpi=140);plt.close(fig);pd.DataFrame(rows).to_csv(O/'image_coordinate_QA.csv',index=False);print(pd.DataFrame(rows).to_string(index=False))
