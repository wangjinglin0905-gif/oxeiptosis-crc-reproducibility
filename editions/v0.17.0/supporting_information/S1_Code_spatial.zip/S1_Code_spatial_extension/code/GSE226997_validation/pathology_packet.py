from pathlib import Path
import json,sys,hashlib,csv
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'work/public_preflight_20261117/deps'))
import numpy as np,pandas as pd
from PIL import Image,ImageDraw
O=ROOT/'outputs/GSE226997_provenance_pathology_v01_2026-11-17';P=O/'pathology_assessment_packet';P.mkdir(exist_ok=True)
D=Path('G:/Doc workout/_公共数据集/data/STimage/GSE226997_b2073c6')
# Assessment images show no expression, score, model output or inferred label.
order=np.random.default_rng(2026111703).permutation(range(7089855,7089859));mapping=[];cropmeta=[]
sheet=Image.new('RGB',(1536,4*560),'white');draw=ImageDraw.Draw(sheet)
for k,n in enumerate(order):
 sid=f'GSM{n}';code=f'B{k+1:02d}';img=Image.open(D/f'GSE226997_{sid}.png').convert('RGB');coords=pd.read_csv(D/f'GSE226997_{sid}_coord.csv',index_col=0)
 mapping.append({'blind_id':code,'sample':sid,'source':str(D/f'GSE226997_{sid}.png'),'width':img.width,'height':img.height})
 # Lossless local review copy; no resampling or stain manipulation.
 img.save(P/f'{code}_HE.png')
 for j,q in enumerate([.25,.5,.75]):
  tx=coords.xaxis.quantile(q);ty=coords.yaxis.quantile(.5);dist=(coords.xaxis-tx)**2+(coords.yaxis-ty)**2;anchor=coords.loc[dist.idxmin()]
  x=int(np.clip(round(anchor.xaxis)-256,0,img.width-512));y=int(np.clip(round(anchor.yaxis)-256,0,img.height-512));crop=img.crop((x,y,x+512,y+512))
  crop.save(P/f'{code}_crop{j+1}_native.png');sheet.paste(crop,(j*512,k*560+36));draw.text((j*512+8,k*560+8),f'{code} native 512px crop {j+1}',fill='black');cropmeta.append({'blind_id':code,'crop':j+1,'x':x,'y':y,'width':512,'height':512,'selection':'coordinate x quartile, median y nearest spot; no score selection'})
sheet.save(O/'native_resolution_contact_sheet.png')
(O/'analyst_only_blind_key.json').write_text(json.dumps(mapping,indent=2),encoding='utf-8')
(P/'crop_positions.json').write_text(json.dumps(cropmeta,indent=2),encoding='utf-8')
with (P/'review_template.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(['blind_id','reviewer','date','coarse_compartment_usable_yes_no_uncertain','reason','tumour_stroma_boundaries_usable','exclude_regions','need_higher_resolution'])
 for row in mapping:w.writerow([row['blind_id'],'','','','','','',''])
print('4 blind image copies, 12 native crops, empty human assessment template; no pathology labels generated')
