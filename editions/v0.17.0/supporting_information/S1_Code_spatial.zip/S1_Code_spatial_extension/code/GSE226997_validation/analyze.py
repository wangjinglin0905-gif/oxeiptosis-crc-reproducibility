from pathlib import Path
import sys,json,hashlib,csv
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R/'work/public_preflight_20261117/deps'));sys.path.insert(0,str(R/'work/spatial_pilot_20261117'))
import numpy as np,pandas as pd
from run import score,rho,partial
C=json.loads(Path(__file__).with_name('contract.json').read_text());D=Path('G:/Doc workout/_公共数据集/data/STimage/GSE226997_b2073c6');O=R/'outputs/GSE226997_validation_v01_2026-11-17';O.mkdir(exist_ok=True)
(O/'contract.json').write_text(json.dumps(C,indent=2),encoding='utf-8')
sets={'OX4':C['target'],**C['references']};members=list(dict.fromkeys(sum(sets.values(),[])));summaries=[];qa=[];reps=[];coverage=[]
for sid in C['samples']:
 p=D/f'GSE226997_{sid}_count.csv';q=D/f'GSE226997_{sid}_coord.csv'
 if not p.exists() or not q.exists():print('UNAVAILABLE',sid);continue
 header=next(csv.reader(p.open(encoding='utf-8')));assert len(set(header[1:]))==len(header)-1,'duplicate gene names'
 present=[g for g in members if g in header];ids=[];totals=[];data=[];integer=True;finite=True
 cache=O/f'{sid}_member_counts_coords.csv.gz'
 expected=next(v['lfs']['oid'] for v in json.loads((O/'HF_count_file_metadata.json').read_text()) if sid in v['path'])
 digest=hashlib.sha256(p.read_bytes()).hexdigest();assert digest==expected
 if cache.exists():
  cached=pd.read_csv(cache,index_col=0);prior=json.loads((O/'input_QA.json').read_text());record=next(v for v in prior if v['sample']==sid);assert record['expression_sha256']==digest
  ids=list(cached.index);totals=list(cached.total_represented_UMI);data=[cached[present].to_numpy()]
 else:
  for chunk in pd.read_csv(p,index_col=0,chunksize=512):
   x=chunk.to_numpy();finite=finite and bool(np.isfinite(x).all() and (x>=0).all());integer=integer and bool(np.equal(x,np.floor(x)).all());ids+=list(chunk.index);totals.extend(x.sum(axis=1));data.append(chunk[present].to_numpy())
 assert finite and integer,'not suitable molecule counts'
 assert len(ids)==len(set(ids));coord=pd.read_csv(q,index_col=0);assert coord.index.is_unique and set(ids)==set(coord.index);coord=coord.loc[ids];assert np.isfinite(coord[['xaxis','yaxis','r']]).all().all()
 t=np.asarray(totals,dtype=np.int64);x=np.concatenate(data).astype(np.int64);ok=t>=500
 table=pd.DataFrame(x,columns=present,index=ids);table['total_represented_UMI']=t;table['eligible']=ok;table=table.join(coord);table.to_csv(O/f'{sid}_member_counts_coords.csv.gz',compression='gzip')
 qa.append({'sample':sid,'n_spots':len(ids),'n_genes':len(header)-1,'eligible':int(ok.sum()),'integer_nonnegative':True,'exact_coordinate_keys':True,'median_depth':float(np.median(t[ok])),'expression_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'coordinate_sha256':hashlib.sha256(q.read_bytes()).hexdigest()})
 for label,genes in sets.items():
  missing=[g for g in genes if g not in present];coverage.append({'sample':sid,'set':label,'missing':';'.join(missing),'complete':not missing})
  if missing:continue
  c=table.loc[ok,genes].to_numpy(dtype=np.int64);tt=t[ok];full,mu,sd=score(c,tt);assert np.isfinite(full).all();vs=[];pcs=[]
  for rep in range(30):
   rng=np.random.default_rng(np.random.SeedSequence([C['seed'],int(sid[3:]),list(sets).index(label),rep]));ca=rng.binomial(c,.5);ta=ca.sum(axis=1)+rng.binomial(tt-c.sum(axis=1),.5);cb=c-ca;tb=tt-ta
   a,_,_=score(ca,ta,mu,sd);b,_,_=score(cb,tb,mu,sd);v=rho(a,b);pc=partial(a,b,ta,tb);vs.append(v);pcs.append(pc);reps.append({'sample':sid,'set':label,'rep':rep,'split_rho':v,'partial_rho':pc})
  summaries.append({'sample':sid,'set':label,'n_spots':len(tt),'all4_positive':float((c>0).all(axis=1).mean()),'median_split_rho':float(np.median(vs)),'p10':float(np.quantile(vs,.1)),'p90':float(np.quantile(vs,.9)),'median_partial_rho':float(np.median(pcs)),'score_depth_rho':rho(full,np.log1p(tt))})
 print(sid,'done',len(ids),flush=True)
pd.DataFrame(summaries).to_csv(O/'summary.csv',index=False);pd.DataFrame(reps).to_csv(O/'replicates.csv',index=False);pd.DataFrame(coverage).to_csv(O/'member_coverage.csv',index=False);(O/'input_QA.json').write_text(json.dumps(qa,indent=2),encoding='utf-8');print(pd.DataFrame(summaries).to_string(index=False))
