"""Package completed analysis, without modifying shared input or manuscript."""
from pathlib import Path
import hashlib
import json
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'outputs/Zenodo7760264_morphology_v01_2026-11-18'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
run = json.loads((OUT / 'run_summary.json').read_text())
assert sha(ROOT / 'work/morphology_20261118/run.py') == run['code_sha256']
assert sha(OUT / 'analysis_contract.md') == run['contract_sha256']
sec = pd.read_csv(OUT / 'target_section_results.csv')
spl = pd.read_csv(OUT / 'all_splits.csv')
assert len(sec) == 36 and len(spl) == 37080
assert not spl[['rho_all', 'rho_tumor', 'delta_half_a', 'delta_half_b']].isna().any().any()
assert spl.rho_stroma.isna().sum() == 3
assert not spl[spl.construct.isin(['OX4', 'epithelial', 'stromal'])].isna().any().any()
ox = sec[sec.construct == 'OX4']
assert tuple(ox[['n_analyzable', 'n_tumor', 'n_stroma']].sum()) == (16225, 4027, 5221)
qa_path = OUT / 'QA.json'
qa = json.loads(qa_path.read_text())
baseline = ROOT / 'outputs/Oxeiptosis_postrejection_v13_working_2026-11-17/manuscript_v13_working_2026-11-17.md'
assert sha(baseline) == qa['v13_unchanged_sha256']
qa.update({
    'status': 'numerical_and_visual_diagnostic_checks_passed',
    'visual_review': {
        'file': 'morphology_diagnostic_v01.png',
        'performed': True,
        'observations': 'All four panels legible; no observed clipping or legend occlusion; a/b/c patient-level, d section-level units documented in legend.',
        'final_submission_figure': False,
        'c2pa_final_submission_check_performed': False,
    },
    'split_missingness': {
        'all_spot_rho': 0, 'tumor_rho': 0, 'stroma_rho': 3,
        'target_construct_missing': 0,
        'details': spl[spl.rho_stroma.isna()][['sample', 'construct', 'rep']].to_dict('records'),
        'handling': 'NA retained; subgroup median uses remaining valid splits. Main matched percentiles use all-spot rho, with no missing values.'
    },
    'primary_counts': {'patients': 6, 'sections': 12, 'analyzable_spots': 16225, 'tumor_spots': 4027, 'stroma_spots': 5221}
})
qa_path.write_text(json.dumps(qa, ensure_ascii=False, indent=2), encoding='utf-8')
paths = sorted(p for p in OUT.rglob('*') if p.is_file() and p.name != 'manifest.json')
paths += sorted((ROOT / 'work/morphology_20261118').glob('*.py'))
manifest = {
    'version': 'v01', 'date': '2026-11-18',
    'status': 'completed_and_checked',
    'shared_inputs_read_only': True,
    'manuscript_modified': False, 'external_release_performed': False,
    'files': [{'path': p.relative_to(ROOT).as_posix(), 'bytes': p.stat().st_size, 'sha256': sha(p)} for p in paths]
}
(OUT / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
for f in manifest['files']:
    assert sha(ROOT / f['path']) == f['sha256']
print(json.dumps({'manifest_files_verified': len(paths), 'status': manifest['status'], 'baseline_unchanged': True}))
