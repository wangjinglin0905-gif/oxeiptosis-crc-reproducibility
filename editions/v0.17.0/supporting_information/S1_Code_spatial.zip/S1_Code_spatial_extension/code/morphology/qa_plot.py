from pathlib import Path
import sys,json,hashlib,itertools,platform
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'work/public_preflight_20261117/deps'))
import numpy as np,pandas as pd
from scipy import stats
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
OUT=ROOT/'outputs/Zenodo7760264_morphology_v01_2026-11-18'
tab=pd.read_csv(OUT/'target_section_results.csv');pat=pd.read_csv(OUT/'patient_effects.csv');bg=pd.read_csv(OUT/'matched_background_positions.csv');inf=pd.read_csv(OUT/'patient_inference.csv')
names=['OX4','epithelial','stromal'];errors=[];score_errors=[];rho_errors=[]
for sid in sorted(tab['sample'].unique()):
 od=OUT/'samples'/sid;t=pd.read_csv(od/'target_spot_scores.csv.gz');r=pd.read_csv(od/'summary.csv');constructs=pd.read_csv(od/'constructs.csv');balance=pd.read_csv(od/'candidate_balance.csv')
 assert len(constructs)==103 and len({tuple(sorted(row)) for row in constructs.iloc[3:,1:].to_numpy()})==100
 for row in constructs.iloc[3:,1:].to_numpy():
  assert len(set(row))==4
  for target,gene in zip(['KEAP1','PGAM5','AIFM1','OTUD1'],row):
   b=balance[(balance.target==target)&(balance.candidate==gene)];assert len(b)==1 and .5<=b.iloc[0].mean_ratio<=2 and abs(b.iloc[0].detection_difference)<=.05
 for name in names:
  a=t.loc[t.coarse_label=='tumor',name].to_numpy();b=np.sort(t.loc[t.coarse_label=='stroma',name].to_numpy())
  greater=np.searchsorted(b,a,side='left');less=len(b)-np.searchsorted(b,a,side='right');d=(greater-less).sum()/(len(a)*len(b))
  exp=float(r.loc[r.construct==name,'cliff_delta'].iloc[0]);errors.append(abs(d-exp))
 # Reconstruct full score independently using explicit per-gene arrays and means.
 q=np.load(od/'audit_first_split.npz');counts=q['C'];tot=q['totals'];full=q['full'];W=q['W'];a=q['a'];ta=q['ta']
 log=np.log1p(10000*counts/tot[:,None]);std=(log-log.mean(axis=0))/log.std(axis=0,ddof=1)
 split=pd.read_csv(od/'splits.csv');tum=q['tumor'];stroma=q['stroma']
 for k,name in enumerate(names):
  ix=np.flatnonzero(W[:,k]);f=np.mean(std[:,ix],axis=1);f=f/f.std(ddof=1);score_errors.append(float(abs(f-full[:,k]).max()))
  b=counts-a;tb=tot-ta
  sa=((np.log1p(10000*a[:,ix]/ta[:,None])-log[:,ix].mean(axis=0))/log[:,ix].std(axis=0,ddof=1)).mean(axis=1)
  sb=((np.log1p(10000*b[:,ix]/tb[:,None])-log[:,ix].mean(axis=0))/log[:,ix].std(axis=0,ddof=1)).mean(axis=1)
  rr=stats.spearmanr(sa,sb).statistic;expected=split.loc[(split.construct==name)&(split.rep==0),'rho_all'].iloc[0];rho_errors.append(abs(rr-expected))
assert max(errors)<1e-10 and max(score_errors)<1e-10 and max(rho_errors)<1e-10
assert len(pat)==18 and tab.groupby(['patient','construct']).size().eq(2).all()
for _,r in inf.iterrows():
 x=pat.loc[pat.construct==r.construct,'cliff_delta'].to_numpy();assert abs(x.mean()-r.mean_delta)<1e-12
 assert r.positive_patients+r.negative_patients==6
baseline=ROOT/'outputs/Oxeiptosis_postrejection_v13_working_2026-11-17/manuscript_v13_working_2026-11-17.md';sha=hashlib.sha256(baseline.read_bytes()).hexdigest();assert sha=='03b7afcaadabc5194e536ebac49284daef10347e930bb8415ff4205ca3cd6cb5'
qa={'status':'numerical_checks_passed','n_independently_checked_section_constructs':36,'max_cliff_delta_error':max(errors),'max_score_error':max(score_errors),'max_first_split_rho_error':max(rho_errors),'all_1200_matched_sets_unique_within_section_and_balanced':True,'patient_replicate_counts_correct':True,'v13_unchanged_sha256':sha,'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__,'matplotlib':matplotlib.__version__,'plot_status':'analysis_diagnostic_not_submission_final','human_pathology_review_performed':False}
(OUT/'QA.json').write_text(json.dumps(qa,indent=2),encoding='utf-8')
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
colors=['#0072B2','#D55E00','#009E73'];fig,ax=plt.subplots(2,2,figsize=(11.5,8),layout='constrained')
for k,(name,c) in enumerate(zip(names,colors)):
 r=pat[pat.construct==name].sort_values('patient');x=k+np.linspace(-.16,.16,6)
 ax[0,0].scatter(x,r.cliff_delta,c=c,s=30,label=name)
 ax[0,0].plot([k-.22,k+.22],[r.cliff_delta.mean()]*2,c=c,lw=2)
 ax[0,1].scatter(x,r.median_split_rho,c=c,s=30)
 ax[0,1].plot([k-.22,k+.22],[r.median_split_rho.mean()]*2,c=c,lw=2)
for a in [ax[0,0],ax[0,1]]:a.set_xticks(range(3),['OX4','Epithelial','Stromal']);a.set_xlim(-.5,2.5)
ax[0,0].axhline(0,c='grey',lw=.8,ls='--');ax[0,0].set_ylim(-1.05,1.05);ax[0,0].set_ylabel("Cliff's delta: tumor versus stroma");ax[0,0].set_title('a  Patient-level compartment effects',loc='left')
ax[0,1].set_ylim(0,1);ax[0,1].set_ylabel('Mean of two section median split correlations');ax[0,1].set_title('b  Conditional technical stability',loc='left')
for i,(pid,r) in enumerate(pat[pat.construct=='OX4'].sort_values('patient').iterrows()):
 ax[1,0].plot([0,1],[r.cliff_delta,r.depth_adjusted_delta],marker='o',lw=1.2,label=r.patient)
ax[1,0].set_xticks([0,1],['Unadjusted','Depth-conditioned']);ax[1,0].set_ylabel("Patient mean Cliff's delta (OX4)");ax[1,0].axhline(0,c='grey',ls='--',lw=.8);ax[1,0].legend(fontsize=8,ncol=2,loc='upper right');ax[1,0].set_ylim(-.18,.58);ax[1,0].set_title('c  Depth sensitivity',loc='left')
ax[1,1].scatter(bg.abs_delta_percentile,bg.split_rho_percentile,c=colors[0],s=32)
ax[1,1].axhline(50,c='grey',ls='--',lw=.8);ax[1,1].axvline(50,c='grey',ls='--',lw=.8);ax[1,1].set(xlim=(0,100),ylim=(0,100),xlabel='OX4 absolute compartment effect percentile',ylabel='OX4 split-correlation percentile');ax[1,1].set_title('d  Position among matched sets',loc='left')
fig.savefig(OUT/'morphology_diagnostic_v01.png',dpi=200);fig.savefig(OUT/'morphology_diagnostic_v01.svg');plt.close(fig)
pd.concat([pat.assign(plot_unit='patient'),bg.assign(plot_unit='section')],ignore_index=True).to_csv(OUT/'plotted_values.csv',index=False)
print(json.dumps(qa,indent=2))
