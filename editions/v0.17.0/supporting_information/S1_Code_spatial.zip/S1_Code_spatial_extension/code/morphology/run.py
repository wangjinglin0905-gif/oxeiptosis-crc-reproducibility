from pathlib import Path
import sys,io,json,hashlib,zipfile,time,itertools,collections,argparse
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'work/public_preflight_20261117/deps'))
import numpy as np,pandas as pd,h5py
from scipy import sparse,stats
OUT=ROOT/'outputs/Zenodo7760264_morphology_v01_2026-11-18';GATE=ROOT/'outputs/Zenodo7760264_gate_v01_2026-11-17'
SETS={'OX4':['KEAP1','PGAM5','AIFM1','OTUD1'],'epithelial':['EPCAM','KRT8','KRT18','KRT19'],'stromal':['COL1A1','COL1A2','COL3A1','DCN']}
sampletab=pd.read_csv(GATE/'sample_gate.csv');samples=sorted(sampletab.loc[sampletab.comparison_eligible,'sample'])
ledger=pd.read_csv(GATE/'barcode_label_coordinate_join.csv',keep_default_na=False)
inputs=pd.read_csv(GATE/'verified_input_manifest.csv').set_index('filename')
CONTRACT=hashlib.sha256((OUT/'analysis_contract.md').read_bytes()).hexdigest()
CODE=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
def delta(a,tum,stroma):
 keep=tum|stroma;nt=int(tum.sum());ns=int(stroma.sum())
 ranks=stats.rankdata(a[keep],axis=0)
 return 2*(ranks[tum[keep]].sum(axis=0)-nt*(nt+1)/2)/(nt*ns)-1
def rho(a,b):
 a=stats.rankdata(a,axis=0);b=stats.rankdata(b,axis=0)
 a=a-a.mean(axis=0);b=b-b.mean(axis=0)
 den=np.sqrt((a*a).sum(axis=0)*(b*b).sum(axis=0))
 return np.divide((a*b).sum(axis=0),den,out=np.full(a.shape[1],np.nan),where=den>0)
def one(sid):
 start=time.monotonic();od=OUT/'samples'/sid;od.mkdir(parents=True,exist_ok=True)
 ck=od/'checkpoint.json'
 if ck.exists():
  d=json.loads(ck.read_text());assert d['code_sha256']==CODE and d['contract_sha256']==CONTRACT
  print(sid,'REUSED',flush=True);return
 info=inputs.loc[sid+'.zip'];path=Path(info['path']);sha=hashlib.sha256(path.read_bytes()).hexdigest();assert sha==info.sha256
 with zipfile.ZipFile(path) as z:
  with h5py.File(io.BytesIO(z.read(sid+'/filtered_feature_bc_matrix.h5')),'r') as h:
   g=h['matrix'];names=[x.decode() for x in g['features/name'][:]];barcodes=[x.decode() for x in g['barcodes'][:]]
   types=[x.decode() for x in g['features/feature_type'][:]];assert set(types)=={'Gene Expression'}
   X=sparse.csc_matrix((g['data'][:],g['indices'][:],g['indptr'][:]),shape=tuple(g['shape'][:])).tocsr();X.eliminate_zeros()
 l=ledger[ledger['sample']==sid].set_index('barcode').loc[barcodes]
 totals=np.asarray(X.sum(axis=0)).ravel().astype(np.int64);assert np.array_equal(totals,l.total_gene_expression_counts.to_numpy())
 ok=(l.in_tissue.to_numpy()==1)&(totals>=500)&(~l.coarse_label.isin(['author_exclude','unlabelled']).to_numpy())
 X=X[:,ok];totals=totals[ok];l=l.iloc[np.flatnonzero(ok)].copy();n=X.shape[1]
 tumor=l.coarse_label.to_numpy()=='tumor';stroma=l.coarse_label.to_numpy()=='stroma';assert min(tumor.sum(),stroma.sum())>=30
 counts=collections.Counter(names)
 cp=X.multiply(10000/totals).tocsr();mean=np.asarray(cp.mean(axis=1)).ravel();detect=np.diff(X.indptr)/n
 norm=cp.copy();norm.data=np.log1p(norm.data)
 mu=np.asarray(norm.mean(axis=1)).ravel();var=(np.asarray(norm.power(2).mean(axis=1)).ravel()-mu*mu)*n/(n-1);sd=np.sqrt(np.maximum(var,0))
 excluded=set(sum(SETS.values(),[]))
 pool=np.array([i for i,name in enumerate(names) if counts[name]==1 and name not in excluded and not name.startswith(('MT-','RPL','RPS')) and sd[i]>1e-12],int)
 candidates=[];balances=[]
 for gene in SETS['OX4']:
  idx=names.index(gene);valid=pool[(mean[pool]>=.5*mean[idx])&(mean[pool]<=2*mean[idx])&(np.abs(detect[pool]-detect[idx])<=.05)]
  assert len(valid)>=10,(sid,gene,len(valid))
  distance=np.abs(np.log2(mean[valid]/mean[idx]))+np.abs(detect[valid]-detect[idx])/.05
  order=np.lexsort((valid,distance));candidates.append(valid[order[:30]])
  for i in valid[order[:30]]:balances.append({'target':gene,'candidate':names[i],'mean_ratio':mean[i]/mean[idx],'detection_difference':detect[i]-detect[idx],'pool_eligible':len(valid)})
 pd.DataFrame(balances).to_csv(od/'candidate_balance.csv',index=False)
 si=samples.index(sid);rng=np.random.default_rng(np.random.SeedSequence([20261118,si,99]));idxsets=[[names.index(g) for g in genes] for genes in SETS.values()];labels=list(SETS);seen=set()
 attempts=0
 while len(seen)<100:
  attempts+=1;assert attempts<100000
  pick=tuple(int(rng.choice(c)) for c in candidates);key=tuple(sorted(pick))
  if len(set(pick))<4 or key in seen:continue
  seen.add(key);idxsets.append(list(pick));labels.append(f'random_{len(seen):03d}')
 pd.DataFrame([{'construct':label,**{f'gene{i+1}':names[g] for i,g in enumerate(ix)}} for label,ix in zip(labels,idxsets)]).to_csv(od/'constructs.csv',index=False)
 union=sorted(set(sum(idxsets,[])));umap={k:i for i,k in enumerate(union)};W=np.zeros((len(union),len(labels)))
 for j,ix in enumerate(idxsets):W[[umap[i] for i in ix],j]=.25
 C=X[union].toarray().T.astype(np.int64);rest=totals-C.sum(axis=1);assert (rest>=0).all()
 mus=mu[union];sds=sd[union];assert (sds>0).all()
 Z=(np.log1p(C*10000/totals[:,None])-mus)/sds;S=Z@W;composite_sd=S.std(axis=0,ddof=1);assert (composite_sd>0).all();S=S/composite_sd
 d=delta(S,tumor,stroma);means=S[tumor].mean(axis=0)-S[stroma].mean(axis=0)
 dep=np.log1p(totals);dc=dep-dep.mean();res=S-S.mean(axis=0)-dc[:,None]*((dc@S)/(dc@dc))[None,:];dr=delta(res,tumor,stroma)
 lowmed=l.original_label.str.replace('_',' ',regex=False).isin(['stroma fibroblastic IC low','stroma fibroblastic IC med']).to_numpy()
 ds=delta(S,tumor,lowmed) if lowmed.sum()>=20 else np.full(len(labels),np.nan)
 depthrho=rho(S,np.broadcast_to(dep[:,None],S.shape))
 reps=[]
 for rep in range(30):
  rng=np.random.default_rng(np.random.SeedSequence([20261118,si,rep]))
  a=rng.binomial(C,.5);ta=a.sum(axis=1)+rng.binomial(rest,.5);b=C-a;tb=totals-ta;assert (ta>0).all() and (tb>0).all()
  sa=(((np.log1p(a*10000/ta[:,None])-mus)/sds)@W)/composite_sd
  sb=(((np.log1p(b*10000/tb[:,None])-mus)/sds)@W)/composite_sd
  rr=rho(sa,sb);rt=rho(sa[tumor],sb[tumor]);rs=rho(sa[stroma],sb[stroma]);da=delta(sa,tumor,stroma);db=delta(sb,tumor,stroma)
  for k,label in enumerate(labels):reps.append({'sample':sid,'construct':label,'rep':rep,'rho_all':rr[k],'rho_tumor':rt[k],'rho_stroma':rs[k],'delta_half_a':da[k],'delta_half_b':db[k],'mean_absolute_delta_shift':(abs(da[k]-d[k])+abs(db[k]-d[k]))/2})
  if rep==0:
   np.savez_compressed(od/'audit_first_split.npz',C=C,totals=totals,union_names=np.array([names[i] for i in union]),W=W,mu=mus,sd=sds,composite_sd=composite_sd,full=S[:,:3],a=a,ta=ta,tumor=tumor,stroma=stroma)
 repdf=pd.DataFrame(reps);repdf.to_csv(od/'splits.csv',index=False)
 result=[]
 for k,label in enumerate(labels):
  r=repdf[repdf.construct==label]
  result.append({'sample':sid,'patient':l.patient.iloc[0],'construct':label,'n_analyzable':n,'n_tumor':int(tumor.sum()),'n_stroma':int(stroma.sum()),'n_lowmed_stroma':int(lowmed.sum()),'cliff_delta':d[k],'mean_difference_sd':means[k],'depth_adjusted_delta':dr[k],'lowmed_stroma_delta':ds[k],'score_depth_rho':depthrho[k],'median_split_rho':r.rho_all.median(),'p10_split_rho':r.rho_all.quantile(.1),'p90_split_rho':r.rho_all.quantile(.9),'median_tumor_rho':r.rho_tumor.median(),'median_stroma_rho':r.rho_stroma.median(),'undefined_tumor_splits':int(r.rho_tumor.isna().sum()),'undefined_stroma_splits':int(r.rho_stroma.isna().sum()),'median_half_delta_shift':r.mean_absolute_delta_shift.median()})
 result=pd.DataFrame(result);result.to_csv(od/'summary.csv',index=False)
 l[['patient','original_label','coarse_label','total_gene_expression_counts','x_hires','y_hires']].assign(OX4=S[:,0],epithelial=S[:,1],stromal=S[:,2]).to_csv(od/'target_spot_scores.csv.gz',compression='gzip')
 bg=result.iloc[3:];target=result.iloc[0]
 pct={'sample':sid,'patient':target.patient,'ox4_delta':target.cliff_delta,'abs_delta_percentile':100*np.mean(np.abs(bg.cliff_delta)<=abs(target.cliff_delta)),'split_rho_percentile':100*np.mean(bg.median_split_rho<=target.median_split_rho),'median_background_abs_delta':float(np.median(abs(bg.cliff_delta))),'median_background_split_rho':float(bg.median_split_rho.median())}
 (od/'background_position.json').write_text(json.dumps(pct,indent=2),encoding='utf-8')
 qa={'sample':sid,'input_sha256':sha,'contract_sha256':CONTRACT,'code_sha256':CODE,'filtered_n':len(barcodes),'analyzable_n':n,'excluded_author_or_blank_after_depth':int(((totals>=500)).sum()) if False else int((l.coarse_label=='author_exclude').sum()),'sets':len(labels),'splits_per_set':30,'runtime_seconds':time.monotonic()-start,'completed':True}
 qa['excluded_author_or_blank_after_depth']=int(((ledger['sample']==sid)&ledger.qc_ge500_in_tissue.astype(str).str.lower().eq('true')&ledger.coarse_label.isin(['author_exclude','unlabelled'])).sum())
 ck.write_text(json.dumps(qa,indent=2),encoding='utf-8')
 print(sid,'DONE',round(qa['runtime_seconds'],1),'sec',result.iloc[:3][['construct','cliff_delta','median_split_rho']].to_dict('records'),flush=True)

def aggregate():
 frames=[];bg=[];splits=[];checkpoints=[]
 for sid in samples:
  od=OUT/'samples'/sid;ck=json.loads((od/'checkpoint.json').read_text());assert ck['contract_sha256']==CONTRACT and ck['code_sha256']==CODE;checkpoints.append(ck)
  frames.append(pd.read_csv(od/'summary.csv'));bg.append(json.loads((od/'background_position.json').read_text()));splits.append(pd.read_csv(od/'splits.csv'))
 allr=pd.concat(frames,ignore_index=True);allr.to_csv(OUT/'all_constructs.csv',index=False);pd.concat(splits,ignore_index=True).to_csv(OUT/'all_splits.csv',index=False);pd.DataFrame(bg).to_csv(OUT/'matched_background_positions.csv',index=False)
 target=allr[allr.construct.isin(SETS)].copy();target.to_csv(OUT/'target_section_results.csv',index=False)
 cols=['cliff_delta','mean_difference_sd','depth_adjusted_delta','lowmed_stroma_delta','median_split_rho','median_tumor_rho','median_stroma_rho','median_half_delta_shift']
 pat=target.groupby(['patient','construct'])[cols].mean().reset_index()
 # Secondary subtype effect requires both sections available; do not silently average one.
 for (patient,c),group in target.groupby(['patient','construct']):
  if group.lowmed_stroma_delta.isna().any():pat.loc[(pat.patient==patient)&(pat.construct==c),'lowmed_stroma_delta']=np.nan
 pat.to_csv(OUT/'patient_effects.csv',index=False)
 infer=[];sgn=np.array(list(itertools.product([-1,1],repeat=6)))
 for k,c in enumerate(SETS):
  x=pat[pat.construct==c].cliff_delta.to_numpy();assert len(x)==6
  rng=np.random.default_rng(20261118+k);boot=x[rng.integers(0,6,size=(10000,6))].mean(axis=1)
  perm=np.abs((sgn*x).mean(axis=1));p=float(np.mean(perm>=abs(x.mean())-1e-12))
  sections=target[target.construct==c];agreement=sum(np.prod(np.sign(v.cliff_delta.to_numpy()))>0 for _,v in sections.groupby('patient'))
  loo=np.array([np.delete(x,j).mean() for j in range(6)])
  infer.append({'construct':c,'n_patients':6,'mean_delta':x.mean(),'bootstrap_lo':np.quantile(boot,.025),'bootstrap_hi':np.quantile(boot,.975),'exact_signflip_p':p,'positive_patients':int((x>0).sum()),'negative_patients':int((x<0).sum()),'same_sign_section_pairs':int(agreement),'leave_one_patient_out_min':loo.min(),'leave_one_patient_out_max':loo.max()})
 inf=pd.DataFrame(infer);ps=inf.exact_signflip_p.to_numpy();order=np.argsort(ps);q=np.minimum.accumulate((ps[order]*3/np.arange(1,4))[::-1])[::-1];adj=np.empty(3);adj[order]=np.minimum(1,q);inf['BH_q_three_scores']=adj;inf.to_csv(OUT/'patient_inference.csv',index=False)
 (OUT/'run_summary.json').write_text(json.dumps({'completed_sections':12,'patients':6,'construct_sections':len(allr),'technical_replicate_rows':sum(len(f) for f in splits),'contract_sha256':CONTRACT,'code_sha256':CODE,'checkpoints':checkpoints},indent=2),encoding='utf-8');print(inf.to_string(index=False),flush=True)

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('stage',choices=['pilot','rest','aggregate']);a=ap.parse_args()
 if a.stage=='pilot':one(samples[0])
 elif a.stage=='rest':
  for s in samples:one(s)
  aggregate()
 else:aggregate()
