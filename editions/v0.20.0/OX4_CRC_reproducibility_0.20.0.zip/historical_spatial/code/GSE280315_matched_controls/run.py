from pathlib import Path
import sys,json,time,hashlib,collections
R=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(R/'work/public_preflight_20261117/deps'))
sys.path.insert(0,str(R/'code/GSE280315_scale_pilot'))
import numpy as np,pandas as pd,h5py
from scipy import sparse
from run import score,rho,partial
C=json.loads(Path(__file__).with_name('contract.json').read_text())
O=R/'outputs/GSE280315_matched_controls_v01_2026-11-17';O.mkdir(exist_ok=True)
D=Path('data/GEO/GSE280315')
P=R/'outputs/GSE280315_region_pilot_v01_2026-11-17'
(O/'contract.json').write_text(json.dumps(C,indent=2),encoding='utf-8')
def section(p):
 start=time.monotonic();name=p.name.split('_')[1];dest=O/name;dest.mkdir(exist_ok=True)
 old=json.loads((P/name/'run.json').read_text());sha=hashlib.sha256(p.read_bytes()).hexdigest();assert sha==old['h5_sha256']
 with h5py.File(p,'r') as f:
  m=f['matrix'];names=np.array([x.decode() for x in m['features/name'][:]]);bc=[x.decode() for x in m['barcodes'][:]]
  mat=sparse.csc_matrix((m['data'][:],m['indices'][:],m['indptr'][:]),shape=tuple(m['shape'][:]))
 rc=np.array([[int(x.split('_')[2]),int(x.split('_')[3].split('-')[0])] for x in bc]);keys,inv=np.unique(rc//8,axis=0,return_inverse=True)
 A=sparse.csr_matrix((np.ones(len(bc),dtype=np.int64),(np.arange(len(bc)),inv)),shape=(len(bc),len(keys)))
 agg=(mat@A).tocsr();del mat,A
 t=np.asarray(agg.sum(axis=0)).ravel();nb=np.bincount(inv);ok=(nb>=32)&(t>=500);t=t[ok].astype(np.int64);agg=agg[:,ok].tocsr()
 prior=pd.read_csv(P/name/'regions_64um_origin.csv.gz');pt=prior[prior.eligible]
 assert np.array_equal(t,pt.total_UMI) and np.array_equal(keys[ok],pt[['grid_row','grid_col']])
 G=C['target'];idx={g:int(np.flatnonzero(names==g)[0]) for g in G+sum(C['positive_references'].values(),[]) if np.sum(names==g)==1}
 availability={label:{'available':all(g in idx for g in genes),'missing_or_ambiguous':[g for g in genes if g not in idx]} for label,genes in C['positive_references'].items()}
 (dest/'reference_availability.json').write_text(json.dumps(availability,indent=2))
 assert np.array_equal(agg[[idx[g] for g in G]].toarray().T,pt[[g+'_UMI' for g in G]])
 means=np.asarray(agg.multiply(10000/t).mean(axis=1)).ravel();det=np.asarray((agg>0).mean(axis=1)).ravel()
 counts=collections.Counter(names);excluded=set(G+sum(C['positive_references'].values(),[]))
 valid=np.array([counts[g]==1 and g not in excluded and not g.startswith(('MT-','RPL','RPS')) for g in names])&(means>0)
 pd.DataFrame({'gene':names,'mean_CP10K':means,'detection':det,'candidate_eligible':valid}).to_csv(dest/'gene_marginals.csv.gz',index=False)
 pools=[];balance=[]
 for g in G:
  i=idx[g];lr=np.log2(np.maximum(means,1e-300)/means[i]);dd=det-det[i];hit=np.flatnonzero(valid&(np.abs(lr)<=1)&(np.abs(dd)<=.05))
  hit=hit[np.argsort(lr[hit]**2+(dd[hit]/.05)**2,kind='stable')][:30]
  assert len(hit)>=10, f'{name} {g}: insufficient pool {len(hit)}; do not relax'
  pools.append(hit)
  for j in hit:balance.append({'target':g,'candidate':names[j],'target_mean':means[i],'candidate_mean':means[j],'log2_mean_ratio':lr[j],'target_detection':det[i],'candidate_detection':det[j],'detection_difference':dd[j]})
 pd.DataFrame(balance).to_csv(dest/'candidate_pools.csv',index=False)
 rng=np.random.default_rng(np.random.SeedSequence([C['seed'],int(p.name[3:10])]))
 sets=[('OX4',G)]+[(label,genes) for label,genes in C['positive_references'].items() if availability[label]['available']];seen=set()
 for k in range(100):
  for attempt in range(10000):
   chosen=[int(rng.choice(pool)) for pool in pools];key=tuple(sorted(chosen))
   if len(set(chosen))==4 and key not in seen:break
  else:raise RuntimeError('unique matching exhausted')
  seen.add(key);sets.append((f'matched_{k:03}',names[chosen].tolist()))
 (dest/'sets.json').write_text(json.dumps(sets,indent=2))
 summary=[];reps=[]
 for k,(label,genes) in enumerate(sets):
  ix=[int(np.flatnonzero(names==g)[0]) for g in genes];c=agg[ix].toarray().T.astype(np.int64)
  full,mu,sd=score(c,t);assert np.isfinite(full).all()
  vals=[];pcs=[]
  for rep in range(10):
   rnd=np.random.default_rng(np.random.SeedSequence([C['seed'],int(p.name[3:10]),k,rep]))
   ca=rnd.binomial(c,.5);ta=ca.sum(axis=1)+rnd.binomial(t-c.sum(axis=1),.5);cb=c-ca;tb=t-ta
   a,_,_=score(ca,ta,mu,sd);b,_,_=score(cb,tb,mu,sd);v=rho(a,b);pc=partial(a,b,ta,tb);vals.append(v);pcs.append(pc)
   reps.append({'sample':name,'set':label,'replicate':rep,'rho':v,'partial_rho':pc})
  summary.append({'sample':name,'set':label,'genes':';'.join(genes),'n_regions':len(t),'median_split_rho':np.median(vals),'median_partial_rho':np.median(pcs),'score_depth_rho':rho(full,np.log1p(t)),'all4_positive':(c>0).all(axis=1).mean()})
  if k%25==0:print(name,label,round(time.monotonic()-start,1),flush=True)
 pd.DataFrame(summary).to_csv(dest/'summary.csv',index=False);pd.DataFrame(reps).to_csv(dest/'replicates.csv',index=False)
 (dest/'run.json').write_text(json.dumps({'completed':True,'seconds':time.monotonic()-start,'h5_sha256':sha,'regions':len(t),'sets':len(sets),'contract_sha256':hashlib.sha256(Path(__file__).with_name('contract.json').read_bytes()).hexdigest()},indent=2))
 print('DONE',name,round(time.monotonic()-start,1),flush=True)
if __name__=='__main__':
 for p in sorted(D.glob('*filtered_feature_bc_matrix.h5')):
  if (O/p.name.split('_')[1]/'run.json').exists():continue
  section(p)
 for fn in ['summary.csv','replicates.csv']:
  pd.concat([pd.read_csv(p) for p in O.glob('*/'+fn)],ignore_index=True).to_csv(O/fn,index=False)
