from pathlib import Path
import sys,json,gzip,hashlib,time,argparse
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R/'work/public_preflight_20261117/deps'))
import numpy as np,pandas as pd,h5py,pyarrow.parquet as pq
from scipy import sparse,stats
import psutil
C=json.loads((Path(__file__).parent/'analysis_contract.json').read_text(encoding='utf-8'))
O=R/'outputs/GSE280315_region_pilot_v01_2026-11-17';O.mkdir(parents=True,exist_ok=True)
D=Path('data/GEO/GSE280315');G=C['genes']
def rho(x,y):
 m=np.isfinite(x)&np.isfinite(y)
 return float(stats.spearmanr(x[m],y[m]).statistic) if m.sum()>3 and np.std(x[m])>0 and np.std(y[m])>0 else float('nan')
def partial(x,y,da,db):
 X=np.column_stack([np.ones(len(x)),stats.rankdata(da),stats.rankdata(db)])
 a=stats.rankdata(x);b=stats.rankdata(y)
 return float(np.corrcoef(a-X@np.linalg.lstsq(X,a,rcond=None)[0],b-X@np.linalg.lstsq(X,b,rcond=None)[0])[0,1])
def score(c,t,mu=None,sd=None):
 x=np.log1p(c/np.maximum(t[:,None],1)*10000)
 if mu is None:mu=x.mean(axis=0);sd=x.std(axis=0,ddof=1)
 if np.any(sd<=0):return np.full(len(x),np.nan),mu,sd
 return ((x-mu)/sd).mean(axis=1),mu,sd
def run(p):
 started=time.monotonic();prefix=p.name.replace('_filtered_feature_bc_matrix.h5','');name=prefix.split('_')[1]
 dest=O/name;dest.mkdir(exist_ok=True)
 prior=json.loads((R/'outputs/public_data_preflight_v01_2026-11-17/input_manifest.json').read_text(encoding='utf-8'))
 expected=next(e['sha256'] for e in prior if Path(e['path']).name==p.name)
 actual=hashlib.sha256(p.read_bytes()).hexdigest();assert actual==expected,'input drift'
 with h5py.File(p,'r') as f:
  m=f['matrix'];names=[s.decode() for s in m['features/name'][:]];bc=[s.decode() for s in m['barcodes'][:]]
  matrix=sparse.csc_matrix((m['data'][:],m['indices'][:],m['indptr'][:]),shape=tuple(m['shape'][:]))
 assert (matrix.data>=0).all() and np.equal(matrix.data,np.floor(matrix.data)).all()
 totals=np.asarray(matrix.sum(axis=0)).ravel().astype(np.int64)
 genes=matrix[[names.index(g) for g in G],:].toarray().T.astype(np.int64);del matrix
 pos=pq.read_table(gzip.open(D/(prefix+'_tissue_positions.parquet.gz'),'rb')).to_pandas().set_index('barcode').loc[bc]
 assert pos.index.is_unique and (pos.in_tissue==1).all()
 rr=pos.array_row.to_numpy().astype(int);cc=pos.array_col.to_numpy().astype(int)
 summaries=[];replicates=[];projections={};refs={}
 for um in [32,64,128,256]:
  side=um//8
  for shifted in [False,True]:
   offset=side//2 if shifted else 0
   coords=np.column_stack([(rr+offset)//side,(cc+offset)//side])
   keys,inv=np.unique(coords,axis=0,return_inverse=True)
   nb=np.bincount(inv);lib=np.bincount(inv,weights=totals).astype(np.int64)
   cnt=np.column_stack([np.bincount(inv,weights=genes[:,j]) for j in range(4)]).astype(np.int64)
   assert np.array_equal(cnt.sum(axis=0),genes.sum(axis=0)) and lib.sum()==totals.sum()
   ok=(nb>=side*side*.5)&(lib>=500)
   y,mu,sd=score(cnt[ok],lib[ok]);projection=np.full(len(nb),np.nan);projection[ok]=y
   projections[(um,shifted)]=projection[inv]
   tab=pd.DataFrame({'grid_row':keys[:,0],'grid_col':keys[:,1],'n_bins':nb,'tissue_fraction':nb/(side*side),'total_UMI':lib,'eligible':ok,'spatial_OX4':projection})
   for j,g in enumerate(G):tab[g+'_UMI']=cnt[:,j]
   tab.to_csv(dest/f'regions_{um}um_{"shifted" if shifted else "origin"}.csv.gz',index=False,compression='gzip')
   if shifted:continue
   refs[str(um)]={'mean':mu.tolist(),'sd':sd.tolist(),'genes':G}
   a=cnt[ok];t=lib[ok];n=len(t);corrs=[];adjusted=[];member_rhos=[[] for _ in G]
   for rep in range(30):
    rng=np.random.default_rng(np.random.SeedSequence([20261117,int(prefix[3:10]),um,rep]))
    ca=rng.binomial(a,0.5);rest=t-a.sum(axis=1);ra=rng.binomial(rest,0.5);ta=ca.sum(axis=1)+ra;cb=a-ca;tb=t-ta
    assert np.array_equal(ca+cb,a) and np.array_equal(ta+tb,t)
    ya,_,_=score(ca,ta,mu,sd);yb,_,_=score(cb,tb,mu,sd)
    v=rho(ya,yb);pc=partial(ya,yb,ta,tb);corrs.append(v);adjusted.append(pc)
    out={'sample':name,'scale_um':um,'replicate':rep,'n_regions':n,'split_rho':v,'depth_partial_split_rho':pc}
    for j,g in enumerate(G):
     gr=rho(np.log1p(ca[:,j]/np.maximum(ta,1)*10000),np.log1p(cb[:,j]/np.maximum(tb,1)*10000));out[g+'_rho']=gr;member_rhos[j].append(gr)
    replicates.append(out)
   cov=float((a>0).all(axis=1).mean()) if n else 0
   dep=rho(y,np.log1p(t));med=float(np.nanmedian(corrs));p10=float(np.nanquantile(corrs,.1))
   summaries.append({'sample':name,'scale_um':um,'all_regions':len(nb),'eligible_regions':n,'eligible_fraction':float(ok.mean()),'median_total_UMI':float(np.median(t)),'all4_positive_fraction':cov,'median_split_rho':med,'p10_split_rho':p10,'p90_split_rho':float(np.nanquantile(corrs,.9)),'median_depth_partial_split_rho':float(np.nanmedian(adjusted)),'score_logdepth_rho':dep,'measurement_gate':bool(n>=50 and cov>=.8 and med>=.7 and p10>=.6 and abs(dep)<=.5)})
 for row in summaries:
  um=row['scale_um'];row['grid_shift_rho_shared_bins']=rho(projections[(um,False)],projections[(um,True)])
 pd.DataFrame(summaries).to_csv(dest/'summary.csv',index=False)
 pd.DataFrame(replicates).to_csv(dest/'split_replicates.csv',index=False)
 scales=[]
 for lo,hi in [(32,64),(64,128),(128,256)]:
  scales.append({'sample':name,'fine_um':lo,'coarse_um':hi,'shared_bin_rho':rho(projections[(lo,False)],projections[(hi,False)]),'independent_validation':False})
 pd.DataFrame(scales).to_csv(dest/'scale_comparison.csv',index=False)
 np.savez_compressed(dest/'base_bin_maps.npz',array_row=rr,array_col=cc,x=pos.pxl_col_in_fullres.to_numpy(),y=pos.pxl_row_in_fullres.to_numpy(),**{f'score_{um}':projections[(um,False)] for um in [32,64,128,256]})
 (dest/'normalization_reference.json').write_text(json.dumps(refs,indent=2),encoding='utf-8')
 log={'sample':name,'h5_sha256':actual,'seconds':time.monotonic()-started,'current_RSS_GiB':psutil.Process().memory_info().rss/2**30,'free_RAM_GiB':psutil.virtual_memory().available/2**30,'n_bins':len(bc),'gene_UMI':dict(zip(G,map(int,genes.sum(axis=0)))),'total_UMI':int(totals.sum()),'completed':True}
 (dest/'run.json').write_text(json.dumps(log,indent=2),encoding='utf-8');print(json.dumps(log),flush=True)
 print(pd.DataFrame(summaries).to_string(index=False),flush=True)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--sample');a=ap.parse_args()
 for p in sorted(D.glob('*filtered_feature_bc_matrix.h5')):
  if a.sample and ('_'+a.sample+'_') not in p.name:continue
  dest=O/p.name.split('_')[1]
  if (dest/'run.json').exists():print('verified checkpoint retained',dest.name);continue
  run(p)
 for fn in ['summary.csv','split_replicates.csv','scale_comparison.csv']:
  files=sorted(O.glob('*/'+fn))
  if files:pd.concat([pd.read_csv(p) for p in files],ignore_index=True).to_csv(O/fn,index=False)
